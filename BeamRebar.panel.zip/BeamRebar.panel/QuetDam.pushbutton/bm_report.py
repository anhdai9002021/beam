# -*- coding: utf-8 -*-
"""Dung noi dung workbook (thuan Python) tu ket qua core.process."""
import os
import datetime
import bm_xlsxw as xlsxw
import bm_keep

INPUT_HDR = [u'Đai (Ø-a gối/a nhịp)', u'Đai trong', u'Ghi chú thép']


def _dir_txt(angle):
    if abs(angle) < 45:
        return u'Ngang (trái → phải)'
    return u'Đứng (trên → dưới)' if angle < 0 else u'Đứng (dưới → trên)'


def build(items, cols, grids, floors, info):
    S = []
    # ---- Info
    rows = [[u'Mục', u'Giá trị']] + [[k, v] for k, v in info]
    S.append(dict(name='Info', rows=rows, widths=[34, 46]))
    # ---- NhomDam (moi dong = 1 dam dien hinh)
    r = [[u'Dầm (Mark)', u'SL', u'Tầng', u'Vị trí (trục)', u'Hướng', u'Góc (độ)', u'L tổng (mm)', u'Số nhịp',
          u'Tiết diện (b x h)', u'Cao đỉnh so với Level (mm)', u'h sàn (mm)',
          u'ElementId Revit (tất cả dầm con)', u'Ghi chú']]
    for it in items:
        ax = it['axis']
        sp = it['spans']
        secs = []
        for s_ in sp:
            for p in s_['pieces']:
                t = u'%dx%d' % (round(p[2]), round(p[3]))
                if t not in secs:
                    secs.append(t)
        tops = []
        for s_ in sp:
            t_ = int(round(s_['top']))
            if t_ not in tops:
                tops.append(t_)
        topx = tops[0] if len(tops) == 1 else u'; '.join(str(t_) for t_ in tops)
        note = []
        if it.get('nomark'):
            note.append(u'Chưa có Mark - hãy đặt Mark trong Revit')
        if it.get('nvariants', 1) > 1 and it.get('variant'):
            note.append(u'Cùng Mark nhưng khác hình dạng/tiết diện (phương án %d/%d)' % (it['variant'], it['nvariants']))
        if any(s_['b'] <= 0 or s_['h'] <= 0 for s_ in sp):
            note.append(u'Thiếu b/h')
        if any(s_['console'] for s_ in sp):
            note.append(u'Có console/đầu tự do')
        if any(s_.get('planted') for s_ in sp):
            note.append(u'Có cột cấy lên dầm (tải tập trung, không phải gối)')
        if any(s_['sec'] for s_ in sp):
            note.append(u'Tiết diện đổi trong nhịp')
        r.append([it['name'], it['count'], u', '.join(it['levels']), it['places'], _dir_txt(ax['angle']),
                  round(ax['angle'], 2), round(ax['L']), len(sp), u'; '.join(secs),
                  topx if sp else 0, max([s_['hs'] for s_ in sp] + [0]),
                  ';'.join(str(i) for i in it['ids']), u'; '.join(note)])
    S.append(dict(name='NhomDam', rows=r, widths=[14, 5, 12, 30, 15, 9, 12, 8, 26, 16, 10, 34, 40]))
    # ---- Nhip (bang nhap thep)
    hdr = [u'Dầm', u'SL', u'Nhịp', u'Loại', u'Gối trái (mm)', u'Loại gối T', u'Trục T', u'Lệch trục T (mm)',
           u'L thông thủy (mm)', u'L tim = trục-trục (mm)', u'Gối phải (mm)', u'Loại gối P', u'Trục P',
           u'Lệch trục P (mm)', u'b (mm)', u'h (mm)', u'Cao đỉnh (mm)', u'h sàn (mm)',
           u'Sàn T dày (mm)', u'Sàn T đỉnh (mm)', u'Sàn P dày (mm)', u'Sàn P đỉnh (mm)', u'Tiết diện đổi trong nhịp',
           u'L trục-trục (mm)', u'Cột cấy trên nhịp (không đỡ dầm)',
           u'Cột đỡ T', u'Vai trò gối T', u'Cột đỡ P', u'Vai trò gối P', u'Cột cấy (tên@vị trí@rộng)',
           u'Cột T cạnh vuông góc dầm (mm)', u'Cột P cạnh vuông góc dầm (mm)',
           u'h dầm đỡ T (mm)', u'h dầm đỡ P (mm)']
    r = [hdr + INPUT_HDR]
    for it in items:
        for s in it['spans']:
            a, b = s['left'], s['right']
            note = u''
            if s['b'] <= 0 or s['h'] <= 0:
                note = u'Thiếu b/h - nhập tay'
            elif s['clear'] <= 0:
                note = u'Nhịp ≤ 0 - kiểm tra mô hình'
            if s.get('dz', 0) > 2:
                note = (note + u'; ' if note else u'') + u'Dầm dốc/lệch cốt 2 đầu dz=%d mm (đỉnh lấy đầu cao)' % round(s['dz'])
            gg = round((b['c'] + b['off']) - (a['c'] + a['off'])) if (a['grid'] and b['grid']) else None
            r.append([it['name'], it['count'], s['idx'], u'Console' if s['console'] else (u'Đoạn' if (a['kind'] == u'Đổi tiết diện' or b['kind'] == u'Đổi tiết diện') else u'Nhịp'),
                      round(a['s1'] - a['s0']), a['kind'], a['grid'], round(a['off']),
                      round(s['clear']), round(s['cc']),
                      round(b['s1'] - b['s0']), b['kind'], b['grid'], round(b['off']),
                      round(s['b']), round(s['h']), round(s['top']), round(s['hs']),
                      round(s['slabL'][0]) if s['slabL'] else 0, round(s['slabL'][1]) if s['slabL'] else None,
                      round(s['slabR'][0]) if s['slabR'] else 0, round(s['slabR'][1]) if s['slabR'] else None, s['sec'], gg, u', '.join(s.get('planted', [])),
                      a.get('ref', ''), a.get('role', ''), b.get('ref', ''), b.get('role', ''), s.get('planted_tok', ''),
                      round(a['dep']) if a.get('dep') else None, round(b['dep']) if b.get('dep') else None,
                      round(a['dh']) if a.get('dh') else None, round(b['dh']) if b.get('dh') else None]
                     + [None] * 2 + [note])
    ni = len(hdr)
    S.append(dict(name='Nhip', rows=r, input_cols=set(range(ni, ni + len(INPUT_HDR))),
                  widths=[14, 5, 6, 9, 11, 10, 8, 10, 12, 10, 11, 10, 8, 10, 8, 8, 10, 9, 10, 12, 10, 12, 34, 14, 28, 12, 34, 12, 34, 30, 14, 14, 12, 12] +
                         [20, 12, 24]))
    # ---- Cot
    r = [[u'Mã cột', u'ElementId', u'Tâm X (mm)', u'Tâm Y (mm)', u'Rộng theo X (mm)', u'Rộng theo Y (mm)', u'Type',
          u'Base Level', u'Base Offset (mm)', u'Top Level', u'Top Offset (mm)',
          u'Chân cột so với Level tầng (mm)', u'Đỉnh cột so với Level tầng (mm)', u'Nguồn cao độ', u'Vai trò với dầm tầng này']]
    for c in cols:
        r.append([c['name'], c['id'], round(c['cx']), round(c['cy']), round(c['wx']), round(c['wy']), c.get('type', ''),
                  c.get('base_lv', ''), round(c.get('boff', 0)), c.get('top_lv', ''), round(c.get('toff', 0)),
                  round(c['zr0']) if c.get('zr0') is not None else None,
                  round(c['zr1']) if c.get('zr1') is not None else None, c.get('zsrc', ''), c.get('role', '')])
    S.append(dict(name='Cot', rows=r, widths=[12, 12, 12, 12, 14, 14, 26, 14, 12, 14, 12, 16, 16, 28, 40]))
    # ---- Luoi
    r = [[u'Tên trục', u'X1', u'Y1', u'X2', u'Y2']]
    for g in grids:
        r.append([g['name'], round(g['p0'][0]), round(g['p0'][1]), round(g['p1'][0]), round(g['p1'][1])])
    S.append(dict(name='Luoi', rows=r, widths=[10, 12, 12, 12, 12]))
    # ---- San
    r = [[u'ElementId', u'Type', u'Dày (mm)', u'Cao đỉnh so với Level (mm)', u'Số đỉnh biên']]
    for f in floors:
        r.append([f['id'], f.get('type', ''), round(f['th']), round(f['top']), len(f['poly'])])
    S.append(dict(name='San', rows=r, widths=[12, 28, 10, 22, 12]))
    # ---- Huong dan
    guide = [
        [u'Hướng dẫn dùng file'],
        [u'0. Mỗi Mark (ví dụ T2.D1) chỉ xuất 1 dầm điển hình; cột SL là số lượng dầm giống hệt. Dầm cùng Mark nhưng khác hình dạng được tách thành T2.D1~2, T2.D1~3...'],
        [u'1. Sheet Nhip: mỗi dòng là 1 nhịp dầm (thông tin quét từ Revit). Cột vàng: đai (Ø-a gối/a nhịp, ví dụ 8-100/200) và ghi chú.'],
        [u'2. Thép dọc được đặt bằng nút "Thép dầm" (nhóm thép), lưu ở sheet Thep. Không cần nhập tay ở đây.'],
        [u'3. Nhịp đánh số theo chiều dầm: dầm ngang từ trái sang phải, dầm đứng theo hướng chọn trong form (mặc định trên → dưới). Gối đánh số G0, G1... từ đầu dầm.'],
        [u'4. Gối = bề rộng cột (hoặc dầm đỡ) đo dọc theo trục dầm; L thông thủy = mép gối đến mép gối; L tim = tim gối đến tim gối.'],
        [u'4b. Sàn: T/P là bên trái/phải khi nhìn dọc theo chiều dầm (dầm ngang nhìn từ trái sang phải: T = phía trên bản vẽ). Dày + cao đỉnh sàn lấy từ Revit, dùng để vẽ sàn trong mặt cắt.'],
        [u'4c. Cột: chỉ cột có CHÂN CỘT thấp hơn đáy dầm (cột băng qua dầm, hoặc cột dưới mà dầm gác lên đầu cột) mới là gối. Cột có chân nằm trong/trên dầm là cột CẤY LÊN DẦM: dầm đi qua bên dưới, không tính là gối - xem cột "Cột cấy trên nhịp" và sheet CotDam.'],
        [u'5. Lệch trục: vị trí trục lưới trừ tâm gối dọc theo dầm (dương = trục nằm về phía cuối dầm). L trục-trục = khoảng cách giữa 2 trục lưới dọc theo dầm (khác L tim khi cột lệch trục).'],
        [u'5b. Cột "h dầm đỡ T/P": chiều cao dầm phụ gác lên dầm này (dùng cho đai bổ sung b + 2h, TCVN 5574:2018 mục 10.4.12). Trống = lấy h dầm đang xét.'],
        [u'6. Đầu tự do: dầm có đầu không có cột/dầm đỡ (console). Kiểm tra lại các dòng này.'],
        [u'7. Toạ độ tính bằng mm theo gốc toạ độ trong của Revit. Không đổi tên sheet.'],
        [u'8. QUÉT LẠI: file cũ được sao lưu vào thư mục backup/. Nhóm thép (Thep), đai nhập tay, tick (Chon) và Cài đặt được GIỮ cho dầm cùng Mark và cùng số nhịp. '
         u'Dầm đổi số nhịp / mất Mark không bị xóa mà chuyển sang sheet ThepCu / DaiCu / NhipCu. Hình học luôn lấy mới từ Revit (kích thước sửa trong tool sẽ bị Revit ghi đè). '
         u'Hãy đóng cửa sổ Thép dầm (và file Excel) trước khi quét lại.'],
    ]
    S.append(dict(name='HuongDan', rows=guide, widths=[140]))
    return S


def write(path, items, cols, grids, floors, info, extra=None, stamp=u''):
    """Ghi file cua 1 tang. Neu file da co: SAO LUU roi GIU nhom thep / dai / cai dat / tick (xem bm_keep).
    Ghi qua file tam roi thay the -> khong bao gio de lai file ghi do dang. Tra ve info giu du lieu (hoac None)."""
    S = build(items, cols, grids, floors, info)
    if extra:
        S = S[:-1] + list(extra) + S[-1:]          # them sheet truoc HuongDan
    kinfo = bm_keep.carry(path, S, stamp)           # co the nem PermissionError / OSError: ben goi xu ly, file cu con nguyen
    tmp = path + '.tmp'
    xlsxw.write_xlsx(tmp, S)
    os.replace(tmp, path)
    return kinfo
