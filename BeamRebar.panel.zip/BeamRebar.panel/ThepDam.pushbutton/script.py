#! python3
# -*- coding: utf-8 -*-
__title__ = u"Thép dầm\n(nhóm thép)"
__author__ = u"Claude"
__doc__ = u"Mở file Excel do nút 'Quét dầm' xuất, đặt thép từng dầm theo nhóm (vẽ bằng bút hoặc nhập bảng), xem triển khai dầm có dim."

import os, sys, json, glob, copy, math, traceback
_HERE = os.path.dirname(os.path.abspath(__file__))
_SHARED = os.path.join(os.path.dirname(_HERE), '_shared')     # bm_ui, bm_revit, bm_xlsxr, bm_xlsxw dung chung 2 nut
for _p in (_SHARED, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)
if not os.path.isdir(_SHARED):
    raise ImportError(u'Thieu thu muc _shared canh thu muc nut (BeamRebar.panel/_shared). Hay giai nen DU CA panel.')

import clr
clr.AddReference("System.Windows.Forms")
clr.AddReference("System.Drawing")
import System
from System import Array, Object, Decimal
from System.Windows.Forms import (Form, Label, ComboBox, TextBox, Button, CheckBox, DataGridView, Panel,
                                  DataGridViewTextBoxColumn, DataGridViewComboBoxColumn,
                                  DataGridViewColumnSortMode, DataGridViewDataErrorContexts,
                                  DataGridViewAutoSizeColumnMode, NumericUpDown, PictureBox, OpenFileDialog,
                                  MessageBox, DialogResult, FormStartPosition, ComboBoxStyle, MessageBoxButtons,
                                  MessageBoxIcon, DockStyle, TableLayoutPanel, RowStyle, ColumnStyle, SizeType,
                                  SplitContainer, Orientation, TabControl, TabPage, FlowLayoutPanel, Padding,
                                  Timer, ScrollBars, DataGridViewTriState, DataGridViewAutoSizeRowsMode,
                                  Appearance, Cursors, MouseButtons, AnchorStyles, AutoSizeMode, BorderStyle,
                                  FormWindowState, DataGridViewSelectionMode, CheckedListBox, CheckState)
from System.Drawing import (Point, Size, Color, Bitmap, Graphics, Pen, SolidBrush, Font, FontStyle,
                            ContentAlignment)
from System.Drawing.Drawing2D import SmoothingMode, DashStyle
from System.Drawing.Text import TextRenderingHint

import builtins
import bm_xlsxw, bm_xlsxr, bm_bars, bm_drawing, bm_sample, bm_rebar, bm_ui, bm_revit, bm_dimtab
import importlib
for _m in (bm_xlsxw, bm_xlsxr, bm_bars, bm_sample, bm_drawing, bm_rebar, bm_ui, bm_dimtab):
    importlib.reload(_m)      # pyRevit giu module cu trong bo nho: nap lai
B, D, R, UI = bm_bars, bm_drawing, bm_rebar, bm_ui
DT = bm_dimtab

DIR = os.path.join(os.path.expanduser('~'), 'Documents', 'BeamRebar')
CFG = os.path.join(DIR, 'defaults.json')
BAD = Color.FromArgb(255, 205, 205)
OKC = Color.Empty
GREY = Color.FromArgb(235, 235, 235)
F = System.Single
RATIOS = [u"Vừa khít", u"1:20", u"1:25", u"1:30", u"1:50", u"1:100"]
VEXS = [u"Tự động", u"1x", u"2x", u"3x", u"5x"]
DIMS = [u"Nhóm đang chọn", u"Tất cả thép", u"Tắt"]
CRITS = [u"Tiết diện đã quét (b x h)", u"Chiều cao h (khoảng)", u"Nhịp thông thủy L (khoảng)"]
CKEYS = ['s', 'h', 'l']
VIEWS = [u"Triển khai dầm", u"Chỉ mặt cắt (dầm này)", u"Mặt cắt các dầm đã tick"]

def pick_beams(owner, items, checked, pal=None):
    """Hop thoai danh sach dam co o tick. items = [(ten, nhan)], checked = tap ten da chon.
    Tra ve tap ten dam duoc chon, hoac None neu bam Huy."""
    dlg = Form()
    dlg.Text = u"Chọn dầm cần tăng cường"
    dlg.Size = Size(580, 620)
    dlg.StartPosition = FormStartPosition.CenterParent
    dlg.MinimizeBox = False
    dlg.MaximizeBox = False
    sel = set(checked)
    shown = []
    busy = [False]
    tl = TableLayoutPanel()
    tl.Dock = DockStyle.Fill
    tl.ColumnCount = 1
    tl.RowCount = 4
    for kind, hh in ((SizeType.Absolute, 38), (SizeType.Absolute, 40), (SizeType.Percent, 100), (SizeType.Absolute, 50)):
        tl.RowStyles.Add(RowStyle(kind, hh))
    r0 = FlowLayoutPanel()
    r0.Dock = DockStyle.Fill
    r0.WrapContents = False
    l0 = Label()
    l0.Text = u"Tìm dầm"
    l0.AutoSize = True
    l0.Margin = Padding(6, 9, 3, 0)
    r0.Controls.Add(l0)
    tb = TextBox()
    tb.Width = 320
    tb.Margin = Padding(3, 6, 3, 0)
    r0.Controls.Add(tb)
    r1 = FlowLayoutPanel()
    r1.Dock = DockStyle.Fill
    r1.WrapContents = False
    cnt = Label()
    cnt.AutoSize = True
    cnt.Margin = Padding(12, 9, 3, 0)
    lb = CheckedListBox()
    lb.Dock = DockStyle.Fill
    lb.CheckOnClick = True
    lb.HorizontalScrollbar = True

    def refresh_count():
        cnt.Text = u"Đã chọn %d / %d dầm" % (len(sel), len(items))

    def fill():
        busy[0] = True
        lb.Items.Clear()
        del shown[:]
        flt = tb.Text.strip().lower()
        for n, lab in items:
            if flt and flt not in lab.lower() and flt not in n.lower():
                continue
            shown.append(n)
            lb.Items.Add(lab, n in sel)
        busy[0] = False
        refresh_count()

    def on_chk(s_, e_):
        if busy[0]:
            return
        n = shown[e_.Index]
        if e_.NewValue == CheckState.Checked:
            sel.add(n)
        else:
            sel.discard(n)
        refresh_count()

    def setall(mode):
        for i in range(lb.Items.Count):
            lb.SetItemChecked(i, (not lb.GetItemChecked(i)) if mode is None else mode)

    for txt_, w_, mode in ((u"Chọn tất cả", 110, True), (u"Bỏ chọn tất cả", 120, False), (u"Đảo chọn", 90, None)):
        b_ = Button()
        b_.Text, b_.Width, b_.Height = txt_, w_, 28
        b_.Margin = Padding(6, 5, 0, 0)
        b_.Click += (lambda m_: (lambda s_, e_: setall(m_)))(mode)
        r1.Controls.Add(b_)
    r1.Controls.Add(cnt)
    r3 = FlowLayoutPanel()
    r3.Dock = DockStyle.Fill
    r3.WrapContents = False
    ok = Button()
    ok.Text, ok.Width, ok.Height = u"Đồng ý", 110, 30
    ok.DialogResult = DialogResult.OK
    ok.Tag = 'primary'
    ok.Margin = Padding(6, 8, 0, 0)
    cc = Button()
    cc.Text, cc.Width, cc.Height = u"Hủy", 90, 30
    cc.DialogResult = DialogResult.Cancel
    cc.Margin = Padding(6, 8, 0, 0)
    r3.Controls.Add(ok)
    r3.Controls.Add(cc)
    tl.Controls.Add(r0, 0, 0)
    tl.Controls.Add(r1, 0, 1)
    tl.Controls.Add(lb, 0, 2)
    tl.Controls.Add(r3, 0, 3)
    dlg.Controls.Add(tl)
    dlg.AcceptButton = ok
    dlg.CancelButton = cc
    lb.ItemCheck += on_chk
    tb.TextChanged += (lambda s_, e_: fill())
    fill()
    if pal:
        try:
            UI.apply(dlg, pal)
        except Exception:
            pass
    try:
        res = dlg.ShowDialog(owner)
    finally:
        dlg.Dispose()
    return set(sel) if res == DialogResult.OK else None



def ask_value(owner, title, prompt, value, pal=None, istext=False):
    """Hop thoai nhap 1 so (mm) hoac 1 chuoi. Tra ve float / str, hoac None neu bam Huy."""
    dlg = Form()
    dlg.Text = title
    dlg.Size = Size(500, 270)
    dlg.StartPosition = FormStartPosition.CenterParent
    dlg.MinimizeBox = False
    dlg.MaximizeBox = False
    lb = Label()
    lb.Text = prompt
    lb.Location, lb.Size = Point(14, 12), Size(460, 90)
    tb = TextBox()
    tb.Location, tb.Width = Point(16, 108), 250
    if istext:
        tb.Text = u'%s' % value
    else:
        v = float(value)
        tb.Text = (u'%d' % round(v)) if abs(v - round(v)) < 1e-9 else (u'%.1f' % v)
    ok = Button()
    ok.Text, ok.Location, ok.Size = u"Đồng ý", Point(16, 150), Size(100, 30)
    ok.DialogResult = DialogResult.OK
    ok.Tag = 'primary'
    cc = Button()
    cc.Text, cc.Location, cc.Size = u"Hủy", Point(124, 150), Size(80, 30)
    cc.DialogResult = DialogResult.Cancel
    for c_ in (lb, tb, ok, cc):
        dlg.Controls.Add(c_)
    dlg.AcceptButton, dlg.CancelButton = ok, cc
    dlg.Shown += (lambda s_, e_: (tb.Focus(), tb.SelectAll()))
    if pal:
        try:
            UI.apply(dlg, pal)
        except Exception:
            pass
    res = None
    try:
        while True:
            if dlg.ShowDialog(owner) != DialogResult.OK:
                break
            if istext:
                res = tb.Text.strip()
                if res:
                    break
                continue
            try:
                res = float(tb.Text.strip().replace(u',', u'.'))
                break
            except Exception:
                MessageBox.Show(u"Hãy nhập một số (mm).", title, MessageBoxButtons.OK, MessageBoxIcon.Warning)
    finally:
        dlg.Dispose()
    return res


TC_D_ITEMS = [u"như thép chủ", u"10", u"12", u"14", u"16", u"18", u"20", u"22", u"25", u"28", u"32"]
TC_D_VALS = [0, 10, 12, 14, 16, 18, 20, 22, 25, 28, 32]
GAPS = [u"Bằng dầm (xuống lớp dưới)", u"30d", u"15d"]
TEMPLATES = [u"Thép trên chạy suốt cả dầm", u"Thép dưới của 1 nhịp (neo 2 đầu)", u"TC trên gối giữa (2 bên)",
             u"TC trên gối đầu (1 đầu gập vào cột)", u"TC trên trong nhịp", u"TC dưới trong nhịp",
             u"Thép uốn (dưới, uốn lên gối phải)", u"Thép uốn (dưới, uốn lên gối trái)", u"Thép giá trong nhịp",
             u"Thép thân (giữa chiều cao dầm)"]

GUIDE = u"""CÁCH ĐIỀN NHÓM THÉP   (xem dầm "★ MẪU HƯỚNG DẪN" đầu danh sách: đã điền sẵn 10 nhóm, cột Ghi chú giải thích từng dòng)

HƯỚNG NHÌN theo trục trên mặt bằng: dầm ngang nhìn từ TRÁI sang PHẢI, dầm đứng nhìn từ TRÊN xuống DƯỚI (G0 là đầu trái / đầu trên).
  (Chọn hướng dầm đứng khi quét. File quét cũ giữ hướng đã quét.)
Mặt cắt nhìn dọc dầm từ G0 về cuối: T = bên trái, P = bên phải khi nhìn. Nếu bạn muốn nhìn ngược, tick "Đảo T/P mặt cắt" ở tab Thiết lập.

SỬA KÍCH THƯỚC, COTE, LƯỚI, ĐAI, SÀN TRỰC TIẾP TRÊN BẢN VẼ (như ô Excel, không cần quét lại Revit)
  Ở chế độ ✋ Chọn / sửa: mọi ô sửa được có KHUNG VÀNG (bật / tắt bằng nút "▣ Hiện ô sửa được"); rê chuột vào ô thì viền cam và
  thanh trạng thái ghi ô đó là gì. BẤM 1 LẦN vào ô -> gõ giá trị -> Enter / Tab sang ô kế, Shift+Enter / Shift+Tab về ô trước,
  Esc hủy, bấm chỗ khác = chốt. Gõ được phép tính, ví dụ =4000+250 hoặc 3*1200.
  Ctrl+Z hoàn tác, Ctrl+Y làm lại (từng lần sửa của dầm đang mở, tối đa 60 lần). Nhớ bấm Lưu Excel.
     - COTE (đỉnh / đáy dầm, trên mặt đứng và trong mặt cắt): gõ MÉT (3.6 hoặc -0.25) hoặc mm (3600). Cote hiện theo tuyệt đối /
       so với Level giống nút "Cote tuyệt đối" ở tab Thiết lập. Sửa cote đỉnh: đáy đổi theo h. Sửa cote đáy: đỉnh giữ nguyên, h đổi.
       Thêm dấu * (vd 3.6*) = đặt cùng cote cho TẤT CẢ nhịp. Trong mặt cắt: áp dụng cho mọi nhịp có mặt cắt giống nhau.
     - TRỤC LƯỚI: bấm vào vòng tròn trục -> đổi TÊN trục (để trống = xóa trục). Số cam cạnh vòng tròn (hoặc số 0 nhỏ nếu chưa lệch)
       = lệch trục - tim gối (+ = lưới nằm bên phải tim gối). Khoảng cách trục-trục sửa ở hàng dim trục-trục.
     - ĐAI: bấm dòng "đai ..." dưới tên nhịp: gõ 8-100/200; thêm * (8-100/200*) = áp dụng mọi nhịp. Dòng "đai trong ..." tương tự.
     - SÀN trong mặt cắt: bấm "d=..." sửa chiều dày (0 = xóa sàn), "+ sàn" để thêm sàn, bấm cote đỉnh sàn để chỉnh cao độ.
     - Bề rộng gối (hàng dưới thân dầm): tim gối giữ nguyên, thông thủy 2 nhịp kề tự đổi.
     - Nhịp: thông thủy (nhãn N1: ...), tim-tim, trục-trục. Thay đổi cộng vào thông thủy, các nhịp phía sau tự dịch, vùng đai vẽ tay dịch theo.
     - Cột cấy: khoảng hở mép gối - mép cột, bề rộng cột (nhập 0 để xóa cột), từ trục lưới đến tim cột.
     - TIẾT DIỆN DẦM: bấm nhãn b x h trong thân nhịp (vd 300x600; thêm * cuối để áp dụng mọi nhịp). Cao đỉnh giữ nguyên, đáy đổi theo h.
     - TIẾT DIỆN CỘT: bấm nhãn dưới chân cột (cột đỡ) hoặc cạnh cột cấy: nhập 'Tên RộngDọcDầm x CạnhVuôngGócDầm' (vd C9 400x600).

VẼ BẰNG BÚT (nhanh nhất)
  ✏ Vẽ thép : chọn SL, Ø rồi kéo chuột trên dầm từ đầu đến cuối thanh thép. Tool tự hiểu trên/giữa/dưới, lớp mấy, mỗi đầu là neo / hết cột / kéo dài / cắt trong nhịp.
  Thép BẺ VÀO CỘT: kéo ngang rồi kéo thẳng xuống (thép dưới: thẳng lên) ở đầu thanh, trong vùng cột -> đầu đó thành "Gập vào cột".
  Thép UỐN XIÊN: kéo nét xiên từ đáy lên mặt trên.
  Combo "Bám": Tiêu chuẩn / Tự do.  Bám tiêu chuẩn:
     - thép lớp trên vẽ ra khỏi gối trong vùng tăng cường (mặc định L/4) -> lấy đúng L/4, và là lớp 2 (lớp 1 là thép chủ);
     - thép lớp dưới vẽ theo tiêu chuẩn (cắt trong nhịp L/6, neo 30d), tăng cường là lớp 2;
     - vẽ HẾT chiều dài dầm -> thép lớp 2, 3, 4 (theo độ cao nét vẽ).
     Combo "Lớp" để ép lớp 1/2/3/4. Giá trị chuẩn chỉnh ở tab Thiết lập.
  ▮ Vẽ đai : chọn Ø đai và a, rồi kéo ngang trên dầm từ điểm đầu đến điểm cuối vùng đai (tự hút vào mép gối, 1/4 nhịp, giữa nhịp).
            Vùng vẽ tay đè lên đai theo nhịp. Tab Đai có nút xóa vùng vẽ cuối / xóa hết.
  ✋ Chọn / sửa : bấm vào thanh thép (màu cam, hiện 2 ô vuông ở đầu), kéo ô vuông để đổi chiều dài, kiểu đầu tự cập nhật.

BẢNG NHÓM THÉP (mỗi dòng = 1 nhóm thanh giống nhau)
  Vị trí  : Trên / Dưới / Giữa (thép thân, thép giá).   Lớp: 1 = sát mép bê tông, 2 = lớp trong...
  SL, Ø   : số thanh và đường kính (mm).
  Từ gối - Đến gối : nhóm chạy từ gối nào đến gối nào (G0, G1... như vòng tròn trục trên hình).
            Từ gối = Đến gối nghĩa là nhóm nằm trên 1 gối (thép mũ), kéo ra hai bên bằng kiểu "Kéo dài ra nhịp".

KIỂU ĐẦU (đầu trái và đầu phải chọn riêng)
  Neo vào gối         : neo thẳng vào gối. Giá trị = chiều dài neo tính từ mép trong gối (30d).
  Hết cột / đầu dầm   : kéo thẳng hết cột hoặc hết đầu dầm.
  Gập vào cột         : kéo vào cột (đến mép ngoài cột trừ lớp bảo vệ) rồi gập 90° SÁT VÀO DẦM: thép trên gập xuống, thép dưới gập lên.
                        Hai chế độ (chọn mặc định ở tab Thiết lập, hoặc ghi riêng từng nhóm ở cột Giá trị):
                          - "Bằng dầm" (ghi: xuống) = gập xuống tới ngay trên lớp thép phía đối diện của dầm;
                          - "30d" = đoạn gập dài 30 lần Ø (cũng có 15d hoặc số mm).
                        Lớp 2 gập lọt vào trong lớp 1 để không đụng nhau.
  Kéo dài ra nhịp     : kéo ra khỏi mép gối. Giá trị = chiều dài (L/3, L/4 hoặc số mm).
  Cắt trong nhịp      : cắt cách mép gối một đoạn đi vào nhịp (dùng cho tăng cường giữa nhịp).
  Giữa gối            : dừng ở tim gối.
  Uốn xiên            : uốn 45° lên (hoặc xuống) mặt đối diện. Giá trị "L/6;L/4" = bắt đầu uốn cách mép gối L/6, rồi đi tiếp qua gối L/4.
GIÁ TRỊ: 30d = 30 lần đường kính | L/3 = 1/3 nhịp thông thủy | 1500 = 1500 mm | xuống. Để trống = dùng mặc định ở tab Thiết lập.

DẦM NHIỀU ĐOẠN, ĐỔI TIẾT DIỆN, HẠ COTE
  Dầm giữa 2 cột có nhiều tiết diện (ví dụ 200x300 > 300x300 > 200x400) hoặc hạ cote đỉnh / đáy được tách thành các ĐOẠN, mỗi đoạn đúng
  b, h, cao độ như Revit. Chỗ đổi tiết diện là "gối ảo" Gk (đường cam nét đứt, bề rộng 0). Mỗi đoạn có tiết diện ghi ngay trên mặt đứng.

DẦM GIẬT CẤP / LỆCH CAO ĐỘ (tab Thiết lập, khung "Giật cấp")
  Khi nhóm thép chạy qua 1 gối (kể cả gối ảo) mà cao độ đỉnh (thép trên, thép thân) hoặc đáy (thép dưới) hai đoạn lệch nhau:
    lệch cote ≤ [mức uốn], mặc định 100 mm  -> thép tự UỐN chuyển tầng, độ dốc 1:6.
    lệch cote lớn hơn                        -> tự động NỐI THẲNG: thép cắt, neo vào dầm / cột theo tiêu chuẩn (30d; gối hẹp thì kéo hết gối
                                                rồi gập đoạn còn thiếu, tối thiểu 15d); tại gối ảo thì chồng 2 thanh qua chỗ đổi tiết diện.
    (tùy chọn) lệch ≤ [mức thẳng]: thép chạy thẳng liền, mặc định 0 = tắt.
  Cột "Kết quả qua gối" ở bảng cho biết từng gối đang ra thẳng / uốn / neo và lệch bao nhiêu mm.
  Cột "Đổi tiết diện" của từng nhóm: Tự động | Luôn neo (cắt) | Luôn uốn | Luôn thẳng (nối liền).

ĐAI
  Tab Đai: nhập đai từng nhịp dạng 8-100/200 (Ø8, a100 vùng gối L/4, a200 giữa nhịp).
  Nhịp thông thủy < 1500 mm (chỉnh ở tab Thiết lập): đai chỉ 1 loại khoảng cách (lấy Ø a100 của vùng gối) suốt nhịp.

TỰ BỐ TRÍ THEO TIẾT DIỆN ĐÃ QUÉT (tab Thiết lập)
  Tiêu chí mặc định "Tiết diện đã quét": bảng liệt kê đúng các tiết diện b x h có trong dữ liệu quét (kèm số nhịp và khoảng L).
  Điền thép cho từng tiết diện: thép trên, thép dưới, tăng cường gối trên, tăng cường nhịp dưới, thép thân, đai.
  Thép đã gán cho 1 tiết diện được nhớ cho các tầng khác. Còn có tiêu chí theo khoảng h hoặc khoảng L nhịp.
  Bấm "Tự bố trí dầm này / TẤT CẢ dầm": mỗi nhịp lấy quy tắc theo h hoặc L của nhịp đó, các nhịp cùng loại thép được nối liền
  (qua gối tự thẳng / uốn / neo theo ngưỡng giật cấp). Sau đó chỉnh lại bằng bút hoặc bảng.

TẦNG, TICK DẦM VÀ XEM MẶT CẮT
  Quét toàn công trình: mỗi tầng / level 1 file Dam_<tầng>.xlsx. Ô "Tầng" trên thanh trên chuyển nhanh giữa các tầng cùng thư mục.
  "☐ Tick dầm" đánh dấu dầm (lưu vào Excel, sheet Chon). Ô "Xem" ở thanh công cụ khung vẽ:
    Triển khai dầm | Chỉ mặt cắt (dầm này) | Mặt cắt các dầm đã tick (xếp lần lượt, dùng để vẽ riêng mặt cắt ngang).

BẢN VẼ TRIỂN KHAI
  Dim: chiều dài từng đoạn thép (neo, uốn, gập, kéo dài), khoảng cách và số đai từng vùng, bề rộng gối, nhịp thông thủy, tim-tim, tổng chiều dài.
  Cote (m): đỉnh và đáy dầm từng đoạn; trong mặt cắt có cote đỉnh dầm, đáy dầm, đỉnh sàn. Mặc định cote tuyệt đối như Revit
  (cao độ tầng theo Project Base Point + vị trí dầm); bỏ tick "Cote tuyệt đối" ở tab Thiết lập để xem cote so với Level.
  Các mặt cắt 1-1, 2-2... (gối trái, giữa nhịp, gối phải của từng nhịp; mặt cắt giống nhau gộp thành 1) có vạch cắt trên mặt đứng,
  vẽ cả SÀN hai bên dầm đúng chiều dày và cao độ như Revit (ghi "giật" khi sàn thấp hơn đỉnh dầm), kèm b, h, lớp bảo vệ,
  khoảng cách thanh, As trên / thân / dưới, cảnh báo "chật" nếu thanh quá sát.
  Ô "Dim thép": Nhóm đang chọn / Tất cả thép / Tắt.

THEO TCVN 5574:2018 (tab Thiết lập, khung "THEO TCVN 5574:2018")
  Nút "Áp dụng": (1) thép thân (10.4.13) cho nhịp h > 700: mỗi mặt đặt nf thanh sao cho khoảng cách ≤ 400, Ø ≥ 12 và
  As mỗi thanh ≥ 0,1% · s · max(b/2; 200); (2) nhịp chưa có đai -> đai cấu tạo; đai có sẵn bị kẹp về a ≤ min(0,5h0; 300) gần gối,
  a ≤ min(0,75h0; 500) giữa nhịp (10.3.4.3), Ø ≥ 6; (3) b ≥ 400 hoặc > 5 thanh / lớp -> đai 4 nhánh (đai trong cùng Ø, a).
  Đai bổ sung chỗ dầm phụ gác lên (10.4.12): tự vẽ vùng đai a = 50 trên đoạn b + 2h của dầm phụ (cần quét lại để có 'h dầm đỡ').
  Tab "Kiểm tra TCVN" liệt kê từng nhịp: đai, ≥ 2 thanh dưới, thép vào gối ≥ 1/2 As và ≥ 2 thanh (10.3.3.5), hàm lượng ≥ 0,1% (10.3.3.1),
  khoảng hở ≥ max(d; 25) (10.3.2), khoảng cách ≤ min(1,5h; 400) (10.3.3.3), thép giá trên, thép thân.
  Lưu ý: giá trị đai mặc định (Ø ≥ 6, 300 / 500) cho bê tông dưới B70; B70-B100 chặt hơn - nhập lại 3 ô "Đai: Ø tối thiểu / trần a" ở tab Thiết lập.

Dầm mẫu chỉ để xem và tập điền, không lưu vào Excel."""


def load_cfg():
    d = dict(ratio=0, vex=0, show_stir=True, dims=0, crit=0, merge=True, top_end=B.K_HET, rules=None, secmem=None, view=0,
             theme=0, abs=True)
    try:
        d.update(json.load(open(CFG, encoding='utf-8')))
    except Exception:
        pass
    return d


def save_cfg(d):
    try:
        if not os.path.isdir(DIR):
            os.makedirs(DIR)
        json.dump(d, open(CFG, 'w', encoding='utf-8'), ensure_ascii=False)
    except Exception:
        pass


def paint_on(bmp, prims):
    """Ve primitive len Bitmap co san (GDI+)."""
    g = Graphics.FromImage(bmp)
    g.SmoothingMode = SmoothingMode.AntiAlias
    g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit
    pens, brushes, fonts = {}, {}, {}

    def pen(col, w, dash=False):
        key = (col, w, dash)
        if key not in pens:
            p = Pen(Color.FromArgb(*col), F(w))
            if dash:
                p.DashStyle = DashStyle.Dash
            pens[key] = p
        return pens[key]

    def brush(col):
        if col not in brushes:
            brushes[col] = SolidBrush(Color.FromArgb(*col))
        return brushes[col]
    try:
        for p in prims:
            k = p[0]
            if k == 'rect':
                _, x, y, w, h, fill, ln = p
                if fill:
                    g.FillRectangle(brush(fill), F(x), F(y), F(w), F(h))
                if ln:
                    g.DrawRectangle(pen(ln, 1), F(x), F(y), F(w), F(h))
            elif k == 'line':
                _, x1, y1, x2, y2, col, w, dash = p
                g.DrawLine(pen(col, w, dash), F(x1), F(y1), F(x2), F(y2))
            elif k == 'circle':
                _, cx, cy, r, fill, ln = p
                g.FillEllipse(brush(fill), F(cx - r), F(cy - r), F(2 * r), F(2 * r))
                g.DrawEllipse(pen(ln, 2), F(cx - r), F(cy - r), F(2 * r), F(2 * r))
            else:
                _, x, y, t, col, size, al, bold = p
                fk = (size, bold)
                if fk not in fonts:
                    fonts[fk] = Font("Segoe UI", F(size), FontStyle.Bold if bold else FontStyle.Regular)
                tw = g.MeasureString(t, fonts[fk]).Width
                x0 = x - tw / 2.0 if al == 'c' else (x - tw if al == 'r' else x)
                g.DrawString(t, fonts[fk], brush(col), F(x0), F(y))
    finally:
        for d in list(pens.values()) + list(brushes.values()) + list(fonts.values()):
            d.Dispose()
        g.Dispose()


def paint(prims, W, H):
    bmp = Bitmap(W, H)
    g = Graphics.FromImage(bmp)
    g.Clear(Color.White)
    g.Dispose()
    paint_on(bmp, prims)
    return bmp


def pick_file():
    dlg = OpenFileDialog()
    dlg.Title = u"Chọn file Excel dầm (do nút Quét dầm xuất)"
    dlg.Filter = "Excel (*.xlsx)|*.xlsx"
    if os.path.isdir(DIR):
        dlg.InitialDirectory = DIR
        files = sorted(glob.glob(os.path.join(DIR, 'Dam_*.xlsx')), key=os.path.getmtime, reverse=True)
        if files:
            dlg.FileName = files[0]
    return dlg.FileName if dlg.ShowDialog() == DialogResult.OK else None


def seg_dist(px, py, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L2 = dx * dx + dy * dy
    t = 0.0 if L2 == 0 else max(0.0, min(1.0, ((px - a[0]) * dx + (py - a[1]) * dy) / L2))
    return math.hypot(px - (a[0] + t * dx), py - (a[1] + t * dy))


class Editor(object):
    def __init__(self, model):
        self.m = model
        self.names = list(model.beams.keys())
        self.cur = None
        self.busy = False
        self.dirty = False
        self.last = None
        self.cfg = load_cfg()
        self.pal = UI.DARK if int(self.cfg.get('theme', 0)) == 1 else UI.LIGHT
        self.runner = bm_revit.get_runner()          # cau noi Revit (ExternalEvent), tao trong ngu canh lenh
        rl = self.cfg.get('rules') or {}
        self.rules = {'h': copy.deepcopy(rl.get('h') or B.DEFAULT_RULES['h']),
                      'l': copy.deepcopy(rl.get('l') or B.DEFAULT_RULES['l']), 's': []}
        self.secmem = {}                                  # (b, h) -> quy tac da gan, nho qua cac tang
        for r in (self.cfg.get('secmem') or []):
            self.secmem[(int(r.get('b', 0)), int(r.get('h', 0)))] = dict(r)
        ci = int(self.cfg.get('crit', 0))
        self.crit_key = CKEYS[ci] if 0 <= ci < len(CKEYS) else 's'
        self.refresh_sections()
        self.tool = 'sel'
        self.ctx = None
        self.base = None
        self.prev_img = None
        self.stroke = None
        self.drag = None
        self.hover_key = None
        self.build()
        self.timer = Timer()
        self.timer.Interval = 250
        self.timer.Tick += self.on_tick
        self.timer.Start()

    # ------------------------------------------------------------ giao dien
    def build(self):
        f = self.f = Form()
        f.Text = u"Thép dầm - " + os.path.basename(self.m.path)
        f.Size = Size(1280, 860)
        f.MinimumSize = Size(950, 620)
        f.StartPosition = FormStartPosition.CenterScreen
        f.Font = UI.font(9.0)
        c, o = self.cfg, self.m.opt

        def lbl(parent, t, x, y, w=100, bold=False):
            l = Label()
            l.Text = t
            l.Location, l.Size = Point(x, y + 3), Size(w, 20)
            if bold:
                l.Font = Font("Segoe UI", F(9), FontStyle.Bold)
            parent.Controls.Add(l)
            return l

        def tb(parent, x, y, w, val):
            t = TextBox()
            t.Location, t.Size = Point(x, y), Size(w, 22)
            t.Text = str(val)
            parent.Controls.Add(t)
            return t

        def num(parent, x, y, w, lo, hi, val, inc=1):
            n = NumericUpDown()
            n.Location, n.Size = Point(x, y), Size(w, 22)
            n.Minimum, n.Maximum, n.Increment = Decimal(lo), Decimal(hi), Decimal(inc)
            n.Value = Decimal(val)
            parent.Controls.Add(n)
            return n

        def combo(parent, x, y, w, items, idx=0):
            cb = ComboBox()
            cb.Location, cb.Size = Point(x, y), Size(w, 22)
            cb.DropDownStyle = ComboBoxStyle.DropDownList
            for it in items:
                cb.Items.Add(it)
            cb.SelectedIndex = idx
            parent.Controls.Add(cb)
            return cb

        def btn(parent, txt, x, y, w, h, fn):
            b = Button()
            b.Text = txt
            b.Location, b.Size = Point(x, y), Size(w, h)
            b.Click += fn
            parent.Controls.Add(b)
            return b

        self.lbl, self.tb_, self.num, self.combo, self.btn = lbl, tb, num, combo, btn

        # --- khung chinh
        root = TableLayoutPanel()
        root.Dock = DockStyle.Fill
        root.ColumnCount, root.RowCount = 1, 3
        root.ColumnStyles.Add(ColumnStyle(SizeType.Percent, F(100)))
        root.RowStyles.Add(RowStyle(SizeType.Absolute, F(42)))
        root.RowStyles.Add(RowStyle(SizeType.Percent, F(100)))
        root.RowStyles.Add(RowStyle(SizeType.Absolute, F(24)))
        f.Controls.Add(root)

        root.Tag = 'bg'
        top = Panel()
        top.Dock = DockStyle.Fill
        top.Tag = 'head'
        root.Controls.Add(top, 0, 0)
        lbl(top, u"Tầng", 6, 9, 36)
        self.files = R.sibling_files(self.m.path)
        fn_ = [self.file_label(p_) for p_ in self.files]
        cur_i = [os.path.abspath(p_) for p_ in self.files].index(os.path.abspath(self.m.path)) if os.path.abspath(self.m.path) in [os.path.abspath(p_) for p_ in self.files] else 0
        if not self.files:
            self.files, fn_, cur_i = [self.m.path], [self.file_label(self.m.path)], 0
        self.c_lvl = combo(top, 44, 9, 140, fn_, cur_i)
        btn(top, u"◀ Dầm trước", 192, 7, 100, 28, lambda s, e: self.step(-1))
        self.cb = combo(top, 298, 9, 290, [self.label(n) for n in self.names], 0)
        btn(top, u"Dầm sau ▶", 594, 7, 100, 28, lambda s, e: self.step(1))
        self.ck_tick = CheckBox()
        self.ck_tick.Appearance = Appearance.Button
        self.ck_tick.Text = u"☐ Tick dầm"
        self.ck_tick.Location, self.ck_tick.Size = Point(702, 7), Size(92, 28)
        self.ck_tick.TextAlign = ContentAlignment.MiddleCenter
        self.ck_tick.Click += self.on_tick_one
        top.Controls.Add(self.ck_tick)
        self.tlab = lbl(top, u"", 800, 9, 90)
        self.info = lbl(top, u"", 892, 9, 420)
        for txt, w, fn in ((u"Đóng", 80, lambda s, e: f.Close()), (u"Lưu Excel", 105, self.on_save)):
            b = Button()
            b.Text, b.Width, b.Dock = txt, w, DockStyle.Right
            if txt == u"Lưu Excel":
                b.Tag = 'primary'
            b.Click += fn
            top.Controls.Add(b)

        sc = self.sc = SplitContainer()
        sc.Dock = DockStyle.Fill
        sc.Orientation = Orientation.Horizontal
        root.Controls.Add(sc, 0, 1)
        self.status = Label()
        self.status.Dock = DockStyle.Fill
        self.status.TextAlign = ContentAlignment.MiddleLeft
        self.status.Tag = 'muted'
        root.Controls.Add(self.status, 0, 2)

        # --- khung ve (tren): thanh cong cu but + ban ve
        self.pan = Panel()
        self.pan.Dock = DockStyle.Fill
        self.pan.AutoScroll = True
        self.pan.BackColor = Color.White
        self.pb = PictureBox()
        self.pb.Location, self.pb.Size = Point(0, 0), Size(800, 300)
        self.pb.MouseDown += self.on_md
        self.pb.MouseMove += self.on_mm
        self.pb.MouseUp += self.on_mu
        self.pb.MouseDoubleClick += self.on_dbl
        self.pan.Controls.Add(self.pb)
        sc.Panel1.Controls.Add(self.pan)
        self.inl = DT.InlineEdit(self)             # sua dim truc tiep tren ban ve (bam so dim, Enter/Tab sang dim ke)

        tbar = FlowLayoutPanel()
        tbar.Dock = DockStyle.Top
        tbar.Height = 74
        tbar.WrapContents = True
        tbar.Tag = 'bg'
        sc.Panel1.Controls.Add(tbar)

        def tbtn(txt, w, on):
            b = CheckBox()
            b.Appearance = Appearance.Button
            b.Text, b.Width, b.Height = txt, w, 27
            b.TextAlign = ContentAlignment.MiddleCenter
            b.Checked = on
            tbar.Controls.Add(b)
            return b

        def tlab(txt):
            l = Label()
            l.Text = txt
            l.AutoSize = True
            l.Margin = Padding(8, 7, 0, 0)
            tbar.Controls.Add(l)

        self.b_sel = tbtn(u"✋ Chọn / sửa", 105, True)
        self.b_pen = tbtn(u"✏ Vẽ thép", 90, False)
        self.b_stir = tbtn(u"▮ Vẽ đai", 80, False)
        self.b_sel.Click += lambda s, e: self.set_tool('sel')
        self.b_pen.Click += lambda s, e: self.set_tool('pen')
        self.b_stir.Click += lambda s, e: self.set_tool('stir')
        self.b_dimundo = Button()
        self.b_dimundo.Text, self.b_dimundo.Width, self.b_dimundo.Height = u"↶ Hoàn tác (Ctrl+Z)", 135, 27
        self.b_dimundo.Click += self.on_dimundo
        tbar.Controls.Add(self.b_dimundo)
        self.b_dimredo = Button()
        self.b_dimredo.Text, self.b_dimredo.Width, self.b_dimredo.Height = u"↷ Làm lại (Ctrl+Y)", 125, 27
        self.b_dimredo.Click += self.on_dimredo
        tbar.Controls.Add(self.b_dimredo)
        self.ck_hint = CheckBox()                        # ve khung quanh MOI o sua duoc (nhu o Excel)
        self.ck_hint.Appearance = Appearance.Button
        self.ck_hint.Text, self.ck_hint.Width, self.ck_hint.Height = u"▣ Hiện ô sửa được", 125, 27
        self.ck_hint.TextAlign = ContentAlignment.MiddleCenter
        self.ck_hint.Checked = True
        tbar.Controls.Add(self.ck_hint)
        tlab(u"SL")
        self.n_pn = NumericUpDown()
        self.n_pn.Width = 46
        self.n_pn.Minimum, self.n_pn.Maximum, self.n_pn.Value = Decimal(1), Decimal(30), Decimal(2)
        tbar.Controls.Add(self.n_pn)
        tlab(u"Ø")
        self.n_pd = NumericUpDown()
        self.n_pd.Width = 46
        self.n_pd.Minimum, self.n_pd.Maximum, self.n_pd.Value = Decimal(6), Decimal(50), Decimal(16)
        tbar.Controls.Add(self.n_pd)
        tlab(u"Lớp")
        self.c_lay = ComboBox()
        self.c_lay.DropDownStyle = ComboBoxStyle.DropDownList
        self.c_lay.Width = 62
        for it in (u"Tự động", u"1", u"2", u"3", u"4"):
            self.c_lay.Items.Add(it)
        self.c_lay.SelectedIndex = 0
        tbar.Controls.Add(self.c_lay)
        tlab(u"Bám")
        self.c_snap = ComboBox()
        self.c_snap.DropDownStyle = ComboBoxStyle.DropDownList
        self.c_snap.Width = 90
        for it in (u"Tiêu chuẩn", u"Tự do"):
            self.c_snap.Items.Add(it)
        self.c_snap.SelectedIndex = 0
        tbar.Controls.Add(self.c_snap)
        self.ck_hook = CheckBox()
        self.ck_hook.Text = u"Đầu ở cột = gập"
        self.ck_hook.AutoSize = True
        self.ck_hook.Margin = Padding(8, 5, 0, 0)
        tbar.Controls.Add(self.ck_hook)
        tlab(u"Đai Ø")
        self.n_sd = NumericUpDown()
        self.n_sd.Width = 44
        self.n_sd.Minimum, self.n_sd.Maximum, self.n_sd.Value = Decimal(5), Decimal(20), Decimal(8)
        tbar.Controls.Add(self.n_sd)
        tlab(u"a")
        self.n_sa = NumericUpDown()
        self.n_sa.Width = 52
        self.n_sa.Minimum, self.n_sa.Maximum, self.n_sa.Value = Decimal(30), Decimal(400), Decimal(100)
        self.n_sa.Increment = Decimal(10)
        tbar.Controls.Add(self.n_sa)
        tlab(u"Dim thép")
        self.c_dim = ComboBox()
        self.c_dim.DropDownStyle = ComboBoxStyle.DropDownList
        self.c_dim.Width = 120
        for it in DIMS:
            self.c_dim.Items.Add(it)
        self.c_dim.SelectedIndex = c['dims'] if isinstance(c['dims'], int) and 0 <= c['dims'] < len(DIMS) else 0
        tbar.Controls.Add(self.c_dim)
        tlab(u"Xem")
        self.c_view = ComboBox()
        self.c_view.DropDownStyle = ComboBoxStyle.DropDownList
        self.c_view.Width = 175
        for it in VIEWS:
            self.c_view.Items.Add(it)
        self.c_view.SelectedIndex = c['view'] if isinstance(c['view'], int) and 0 <= c['view'] < len(VIEWS) else 0
        tbar.Controls.Add(self.c_view)
        for txt, fn in ((u"Tick hết", lambda s_, e: self.tick_all(True)), (u"Bỏ tick", lambda s_, e: self.tick_all(False))):
            b_ = Button()
            b_.Text, b_.Width, b_.Height = txt, 66, 27
            b_.Click += fn
            tbar.Controls.Add(b_)
        for txt, fn in ((u"◎ Chọn trong Revit", lambda s_, e: self.revit_select()),
                        (u"⇩ Lấy dầm đang chọn", lambda s_, e: self.revit_pull())):
            b_ = Button()
            b_.Text, b_.Width, b_.Height = txt, 142, 27
            b_.Click += fn
            tbar.Controls.Add(b_)
        self.ck_sync = CheckBox()
        self.ck_sync.Text = u"Tự chọn trong Revit khi đổi dầm"
        self.ck_sync.AutoSize = True
        self.ck_sync.Margin = Padding(8, 5, 0, 0)
        tbar.Controls.Add(self.ck_sync)
        self.hint = Label()
        self.hint.AutoSize = True
        self.hint.Margin = Padding(12, 7, 0, 0)
        self.hint.ForeColor = Color.FromArgb(110, 110, 110)
        self.hint.Text = u"Vẽ thép: kéo từ đầu đến cuối thanh (kéo thẳng xuống ở cột = gập). Vẽ đai: kéo ngang theo vùng."
        tbar.Controls.Add(self.hint)

        # --- tab (duoi)
        tc = self.tc = TabControl()
        tc.Dock = DockStyle.Fill
        sc.Panel2.Controls.Add(tc)
        p0, p1, p2, p3 = TabPage(u"Nhóm thép"), TabPage(u"Đai"), TabPage(u"Thiết lập"), TabPage(u"Hướng dẫn")
        for p, ttl in ((p0, u"Nhóm thép"), (p1, u"Đai"), (p2, u"Thiết lập"), (p3, u"Hướng dẫn")):
            p.Text = ttl
            tc.TabPages.Add(p)

        p4 = TabPage(u"Kiểm tra TCVN")
        p4.Text = u"Kiểm tra TCVN"
        tc.TabPages.Add(p4)
        tv = self.tv = TextBox()
        tv.Multiline = True
        tv.ReadOnly = True
        tv.ScrollBars = ScrollBars.Vertical
        tv.Dock = DockStyle.Fill
        tv.Font = Font("Consolas", F(9.5))
        p4.Controls.Add(tv)

        # tab 1: nhom thep
        t0 = TableLayoutPanel()
        t0.Dock = DockStyle.Fill
        t0.ColumnCount, t0.RowCount = 1, 2
        t0.ColumnStyles.Add(ColumnStyle(SizeType.Percent, F(100)))
        t0.RowStyles.Add(RowStyle(SizeType.Absolute, F(36)))
        t0.RowStyles.Add(RowStyle(SizeType.Percent, F(100)))
        p0.Controls.Add(t0)
        fl = FlowLayoutPanel()
        fl.Dock = DockStyle.Fill
        fl.WrapContents = False
        t0.Controls.Add(fl, 0, 0)

        def fbtn(txt, w, fn):
            b = Button()
            b.Text, b.Width, b.Height = txt, w, 27
            b.Click += fn
            fl.Controls.Add(b)

        self.c_tpl = ComboBox()
        self.c_tpl.DropDownStyle = ComboBoxStyle.DropDownList
        self.c_tpl.Width = 280
        for it in TEMPLATES:
            self.c_tpl.Items.Add(it)
        self.c_tpl.SelectedIndex = 0
        fl.Controls.Add(self.c_tpl)
        lb = Label()
        lb.Text = u"Gối (0..) / nhịp (1..):"
        lb.AutoSize = True
        lb.Margin = Padding(6, 6, 0, 0)
        fl.Controls.Add(lb)
        self.n_k = NumericUpDown()
        self.n_k.Width = 48
        self.n_k.Minimum, self.n_k.Maximum, self.n_k.Value = Decimal(0), Decimal(60), Decimal(1)
        fl.Controls.Add(self.n_k)
        fbtn(u"Thêm mẫu", 85, self.on_tpl)
        fbtn(u"Thêm nhóm", 90, self.on_add)
        fbtn(u"Nhân đôi", 80, self.on_dup)
        fbtn(u"Xóa nhóm", 85, self.on_del)

        g = self.g = DataGridView()
        g.Dock = DockStyle.Fill
        g.AllowUserToAddRows = False
        g.AllowUserToDeleteRows = False
        g.RowHeadersVisible = False
        g.MultiSelect = False
        g.SelectionMode = DataGridViewSelectionMode.FullRowSelect      # chon thep tren dam -> to mau CA DONG trong bang
        g.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells

        def tcol(h, w, ro=False, fill=False, wrap=False):
            c_ = DataGridViewTextBoxColumn()
            c_.HeaderText, c_.Width, c_.ReadOnly = h, w, ro
            c_.SortMode = DataGridViewColumnSortMode.NotSortable
            if ro:
                c_.DefaultCellStyle.BackColor = GREY
            if wrap:
                c_.DefaultCellStyle.WrapMode = getattr(DataGridViewTriState, 'True')
            if fill:
                c_.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
                c_.MinimumWidth = 220
                c_.DefaultCellStyle.WrapMode = getattr(DataGridViewTriState, 'True')
            g.Columns.Add(c_)

        def ccol(h, w, items):
            c_ = DataGridViewComboBoxColumn()
            c_.HeaderText, c_.Width = h, w
            for it in items:
                c_.Items.Add(it)
            g.Columns.Add(c_)
        tcol(u"STT", 40, True)
        ccol(u"Vị trí", 62, B.POS)
        tcol(u"Lớp", 40)
        tcol(u"SL", 40)
        tcol(u"Ø", 42)
        tcol(u"Từ gối", 52)
        ccol(u"Đầu trái", 135, B.KINDS)
        tcol(u"Giá trị", 70)
        tcol(u"Đến gối", 55)
        ccol(u"Đầu phải", 135, B.KINDS)
        tcol(u"Giá trị", 70)
        ccol(u"Đổi tiết diện", 140, B.CROSS)
        tcol(u"Kết quả qua gối", 170, True, False, True)
        tcol(u"Ghi chú", 100, False, True)
        g.CurrentCellDirtyStateChanged += self.on_dirty
        g.DataError += self.on_dataerr
        t0.Controls.Add(g, 0, 1)

        # tab 2: dai (theo nhip) + vung dai
        t1 = TableLayoutPanel()
        t1.Dock = DockStyle.Fill
        t1.ColumnCount, t1.RowCount = 2, 1
        t1.ColumnStyles.Add(ColumnStyle(SizeType.Percent, F(55)))
        t1.ColumnStyles.Add(ColumnStyle(SizeType.Percent, F(45)))
        p1.Controls.Add(t1)
        s = self.s = DataGridView()
        s.Dock = DockStyle.Fill
        s.AllowUserToAddRows = False
        s.AllowUserToDeleteRows = False
        s.RowHeadersVisible = False
        for h, w, ro in ((u"Nhịp", 50, True), (u"L tt (mm)", 80, True), (u"b x h", 80, True),
                         (u"Đai (Ø-a gối/a nhịp)", 150, False), (u"Đai trong", 110, False)):
            c_ = DataGridViewTextBoxColumn()
            c_.HeaderText, c_.Width, c_.ReadOnly = h, w, ro
            c_.SortMode = DataGridViewColumnSortMode.NotSortable
            if ro:
                c_.DefaultCellStyle.BackColor = GREY
            s.Columns.Add(c_)
        t1.Controls.Add(s, 0, 0)
        rp = TableLayoutPanel()
        rp.Dock = DockStyle.Fill
        rp.ColumnCount, rp.RowCount = 1, 2
        rp.ColumnStyles.Add(ColumnStyle(SizeType.Percent, F(100)))
        rp.RowStyles.Add(RowStyle(SizeType.Absolute, F(34)))
        rp.RowStyles.Add(RowStyle(SizeType.Percent, F(100)))
        t1.Controls.Add(rp, 1, 0)
        zf = FlowLayoutPanel()
        zf.Dock = DockStyle.Fill
        zf.WrapContents = False
        rp.Controls.Add(zf, 0, 0)
        for txt, w, fn in ((u"Xóa vùng vẽ cuối", 120, self.on_zundo), (u"Xóa hết vùng vẽ", 115, self.on_zclear)):
            b_ = Button()
            b_.Text, b_.Width, b_.Height = txt, w, 27
            b_.Click += fn
            zf.Controls.Add(b_)
        self.zlab = Label()
        self.zlab.AutoSize = True
        self.zlab.Margin = Padding(8, 7, 0, 0)
        zf.Controls.Add(self.zlab)
        zg = self.zg = DataGridView()
        zg.Dock = DockStyle.Fill
        zg.ReadOnly = True
        zg.AllowUserToAddRows = False
        zg.RowHeadersVisible = False
        for h, w in ((u"Từ (mm)", 70), (u"Đến (mm)", 70), (u"Ø", 40), (u"a", 45), (u"Số đai", 55), (u"Dài (mm)", 70)):
            c_ = DataGridViewTextBoxColumn()
            c_.HeaderText, c_.Width = h, w
            c_.SortMode = DataGridViewColumnSortMode.NotSortable
            zg.Columns.Add(c_)
        rp.Controls.Add(zg, 0, 1)

        # tab 3: thiet lap (bo cuc tu dong, khong chong chu len khung)
        sf = FlowLayoutPanel()
        sf.Dock = DockStyle.Fill
        sf.AutoScroll = True
        sf.WrapContents = True
        p2.Controls.Add(sf)

        def block(title, rows):
            tl = TableLayoutPanel()
            tl.AutoSize = True
            tl.AutoSizeMode = AutoSizeMode.GrowAndShrink
            tl.ColumnCount = 2
            tl.Margin = Padding(6)
            tl.Padding = Padding(6)
            tl.BorderStyle = BorderStyle.FixedSingle
            hd = Label()
            hd.Text = title
            hd.AutoSize = True
            hd.Font = Font("Segoe UI", F(9), FontStyle.Bold)
            hd.Margin = Padding(3, 3, 3, 8)
            tl.Controls.Add(hd, 0, 0)
            tl.SetColumnSpan(hd, 2)
            for i, (label, ctrl) in enumerate(rows, 1):
                lb = Label()
                lb.Text = label
                lb.AutoSize = True
                if ctrl is None:
                    lb.MaximumSize = Size(380, 0)
                    lb.ForeColor = Color.FromArgb(110, 110, 110)
                    lb.Margin = Padding(3, 6, 3, 3)
                    tl.Controls.Add(lb, 0, i)
                    tl.SetColumnSpan(lb, 2)
                else:
                    lb.Anchor = AnchorStyles.Left
                    lb.Margin = Padding(3, 6, 14, 3)
                    ctrl.Margin = Padding(3, 3, 3, 3)
                    tl.Controls.Add(lb, 0, i)
                    tl.Controls.Add(ctrl, 1, i)
            sf.Controls.Add(tl)
            return tl

        def mnum(lo, hi, val, inc=1, w=70):
            n = NumericUpDown()
            n.Width = w
            n.Minimum, n.Maximum, n.Increment = Decimal(lo), Decimal(hi), Decimal(inc)
            n.Value = Decimal(val)
            return n

        def mtb(val, w=90):
            t = TextBox()
            t.Width = w
            t.Text = str(val)
            return t

        def mcombo(items, idx, w=170):
            cb_ = ComboBox()
            cb_.DropDownStyle = ComboBoxStyle.DropDownList
            cb_.Width = w
            for it in items:
                cb_.Items.Add(it)
            cb_.SelectedIndex = idx
            return cb_

        self.n_cov = mnum(10, 80, o['cover'], 5)
        self.n_str = mnum(0, 500, o['straight'], 5)
        self.n_thr = mnum(0, 1000, o['thr'], 10)
        self.n_slp = mnum(2, 20, o['slope'], 1)
        block(u"GIẬT CẤP / LỆCH CAO ĐỘ DẦM", [
            (u"Lớp bảo vệ (mm)", self.n_cov),
            (u"Lệch cote ≤ (mm): thép tự UỐN", self.n_thr),
            (u"Độ dốc đoạn uốn 1 :", self.n_slp),
            (u"Lệch cote ≤ (mm): chạy thẳng liền (0 = tắt)", self.n_str),
            (u"Lệch cote lớn hơn mức UỐN: thép DẦM TO kéo hết gối rồi BẺ (trên xuống / dưới lên), "
             u"thép DẦM BÉ XUYÊN qua gối vào dầm to thêm 1 đoạn nối = Neo tiêu chuẩn (TCVN).", None)])
        self.t_neo = mtb(o['neo'], 80)
        self.c_gap = ComboBox()
        self.c_gap.DropDownStyle = ComboBoxStyle.DropDown
        self.c_gap.Width = 190
        for it in GAPS:
            self.c_gap.Items.Add(it)
        self.c_gap.Text = self.gap_text(o['gap'])
        self.t_ext = mtb(o['ext'], 80)
        self.n_short = mnum(0, 6000, o['short'], 100)
        block(u"NEO / GẬP / KÉO DÀI / ĐAI", [
            (u"Neo tiêu chuẩn", self.t_neo),
            (u"Gập vào cột", self.c_gap),
            (u"Kéo dài ra nhịp mặc định", self.t_ext),
            (u"Nhịp < (mm): đai 1 khoảng cách", self.n_short),
            (u"Gập: 'Bằng dầm' = gập xuống tới ngay trên lớp thép phía đối diện của dầm; hoặc chọn 30d / 15d "
             u"(đoạn gập = số lần Ø), hoặc gõ số mm.", None)])
        self.t_zt = mtb(o['zone_top'], 80)
        self.t_zb = mtb(o['zone_bot'], 80)
        block(u"BÚT VẼ - BÁM TIÊU CHUẨN", [
            (u"Vùng tăng cường lớp trên", self.t_zt),
            (u"Tăng cường dưới: cắt cách mép gối", self.t_zb),
            (u"Vẽ hết chiều dài dầm = thép lớp 2, 3, 4.", None)])
        self.ck_tcjoin = CheckBox()
        self.ck_tcjoin.Text = u"Bật"
        self.ck_tcjoin.AutoSize = True
        self.ck_tcjoin.Checked = bool(o.get('merge_on', 0.0))
        self.n_mgap = mnum(0, 6000, o.get('merge_gap', 1200.0), 50)
        self.n_near = mnum(0, 3000, o.get('near', 800.0), 50)
        self.n_hclr = mnum(5, 200, o.get('hook_clr', 20.0), 5)
        self.n_pitch = mnum(0, 200, o.get('pitch', 25.0), 5)
        block(u"CHÂN BẺ NEO VÀO CỘT / KHOẢNG HỞ LỚP THÉP", [
            (u"Khoảng hở chân bẻ lên (thép dưới) / bẻ xuống (thép trên) (mm)", self.n_hclr),
            (u"Khoảng hở giữa các lớp thép (mm) - lớp 1, tăng cường, lớp 2...", self.n_pitch),
            (u"TCVN 5574:2018 mục 10.3.2 yêu cầu khoảng hở ≥ max(Ø; 25 mm): dưới 25 mm tab 'Kiểm tra TCVN' sẽ cảnh báo.", None)])
        block(u"TĂNG CƯỜNG: NỐI ĐOẠN / LAO RA CỘT, DẦM PHỤ", [
            (u"Nối 2 đoạn tăng cường thành 1 thanh", self.ck_tcjoin),
            (u"   khi hở giữa 2 đầu ≤ (mm)", self.n_mgap),
            (u"Cột cấy / dầm phụ / gối cách đầu tăng cường ≤ (mm): lao ra", self.n_near),
            (u"Nối: áp dụng khi bấm 'Tự bố trí' (chỉ nối 2 đoạn cùng lớp, vị trí, SL, Ø). "
             u"Lao ra: thép tăng cường kéo qua cột cấy / dầm phụ và neo l_an (theo 'Neo tiêu chuẩn') về phía bên kia; "
             u"Thép tăng cường dưới có đầu cắt cách mép cột đỡ ≤ giá trị này thì vào luôn cột và neo l_an (gối biên hẹp thì bẻ mỏ). "
             u"0 = chỉ kéo khi đầu thanh đã nằm trong vùng neo. Dầm phụ nhận từ lúc quét dầm: cần quét lại để có dữ liệu.", None)])
        self.tc_sel = set()
        self.tcw = {}
        tc_rows = []
        for key, pos_, ly_, title in B.TC_CELLS:
            pn = FlowLayoutPanel()
            pn.AutoSize = True
            pn.WrapContents = False
            ck_ = CheckBox()
            ck_.Text = u"Bật"
            ck_.AutoSize = True
            ck_.Checked = bool(o.get(key + '_on', 0.0))
            ck_.Margin = Padding(3, 4, 12, 0)
            pn.Controls.Add(ck_)
            for txt_ in (u"SL",):
                l_ = Label()
                l_.Text = txt_
                l_.AutoSize = True
                l_.Margin = Padding(3, 6, 3, 0)
                pn.Controls.Add(l_)
            nn_ = mnum(1, 12, o.get(key + '_n', 1.0), 1, 55)
            pn.Controls.Add(nn_)
            l2_ = Label()
            l2_.Text = u"Ø"
            l2_.AutoSize = True
            l2_.Margin = Padding(10, 6, 3, 0)
            pn.Controls.Add(l2_)
            dv_ = int(o.get(key + '_d', 0.0) or 0)
            cb_ = mcombo(TC_D_ITEMS, TC_D_VALS.index(dv_) if dv_ in TC_D_VALS else 0, 110)
            pn.Controls.Add(cb_)
            self.tcw[key] = (ck_, nn_, cb_)
            tc_rows.append((title, pn))
        self.c_tcscope = mcombo([u"Dầm đang chọn", u"Các dầm đã tick ☑ (ở danh sách dầm trên)", u"Tất cả dầm của tầng",
                                 u"Danh sách dầm tự chọn (nút bên dưới)"], 0, 300)
        tc_rows.append((u"Áp dụng cho", self.c_tcscope))
        pn2 = FlowLayoutPanel()
        pn2.AutoSize = True
        pn2.WrapContents = False
        bp_ = Button()
        bp_.Text, bp_.Width, bp_.Height = u"Chọn dầm trong danh sách...", 210, 28
        bp_.Click += self.on_tc_pick
        pn2.Controls.Add(bp_)
        self.l_tcsel = Label()
        self.l_tcsel.Text = u"Chưa chọn dầm nào"
        self.l_tcsel.AutoSize = True
        self.l_tcsel.Margin = Padding(10, 7, 3, 0)
        pn2.Controls.Add(self.l_tcsel)
        tc_rows.append((u"Chọn dầm", pn2))
        self.b_tcapply = Button()
        self.b_tcapply.Text, self.b_tcapply.Width, self.b_tcapply.Height = u"Áp dụng tăng cường", 170, 28
        self.b_tcapply.Tag = 'primary'
        self.b_tcapply.Click += self.on_tc_apply
        tc_rows.append((u"", self.b_tcapply))
        tc_rows.append((u"Tick ô nào thì áp dụng ô đó. Mặc định: lớp 1 = 1 thanh, lớp 2 = 2 thanh, Ø = như thép chủ (lớp 1) cùng vị trí. "
                        u"Trên = mũ gối, kéo vào nhịp L/3 từ mép gối (ô 'Kéo dài ra nhịp'); Dưới = thép nhịp, cắt cách mép gối L/6. "
                        u"Đầu thanh gần cột cấy / dầm phụ tự lao ra và neo l_an, hai đoạn gần nhau tự nối nếu bật ô nối. "
                        u"Áp dụng lại sẽ thay phần tăng cường cũ cùng lớp/vị trí (không đụng thép chủ). "
                        u"Khi có ô được tick, 'Tự bố trí' cũng dùng các ô này thay cho cột TC của bảng quy tắc. "
                        u"Chế độ 'Danh sách dầm tự chọn': bấm 'Chọn dầm trong danh sách...' để mở danh sách, tick các dầm cần tăng cường rồi bấm Áp dụng.", None))
        block(u"THÉP TĂNG CƯỜNG LỚP 1 / LỚP 2, TRÊN / DƯỚI", tc_rows)
        self.ck_skin = CheckBox()
        self.ck_skin.Text = u"Bật"
        self.ck_skin.AutoSize = True
        self.ck_skin.Checked = bool(o.get('skin_on', 1.0))
        self.n_skh = mnum(300, 3000, o.get('skin_h', 700.0), 50)
        self.n_sks = mnum(100, 600, o.get('skin_s', 400.0), 10)
        self.n_skd = mnum(8, 32, o.get('skin_d', 12.0), 1)
        self.n_skr = mnum(0, 1, o.get('skin_ratio', 0.1), 0.05, 70)
        self.n_skr.DecimalPlaces = 2
        self.ck_tst = CheckBox()
        self.ck_tst.Text = u"Bật"
        self.ck_tst.AutoSize = True
        self.ck_tst.Checked = bool(o.get('tcvn_stir', 1.0))
        self.n_a0 = mnum(20, 120, o.get('stir_a0', 50.0), 5)
        self.ck_hang = CheckBox()
        self.ck_hang.Text = u"Bật"
        self.ck_hang.AutoSize = True
        self.ck_hang.Checked = bool(o.get('hang_on', 1.0))
        self.n_hga = mnum(30, 200, o.get('hang_a', 50.0), 10)
        self.n_legb = mnum(150, 1000, o.get('leg_b', 400.0), 50)
        self.n_legn = mnum(2, 12, o.get('leg_n', 5.0), 1)
        self.n_sdm = mnum(6, 16, o.get('stir_dmin', 6.0), 1)
        self.n_sa1 = mnum(100, 500, o.get('stir_a1', 300.0), 10)
        self.n_sa2 = mnum(100, 800, o.get('stir_a2', 500.0), 10)
        pn_tv = FlowLayoutPanel()
        pn_tv.AutoSize = True
        pn_tv.WrapContents = False
        for txt_, w_, all_ in ((u"Áp dụng: dầm này", 130, False), (u"Áp dụng: TẤT CẢ dầm của tầng", 220, True)):
            b_ = Button()
            b_.Text, b_.Width, b_.Height = txt_, w_, 28
            b_.Tag = 'primary'
            b_.Click += (lambda a_: (lambda s_, e_: self.on_tcvn_apply(a_)))(all_)
            pn_tv.Controls.Add(b_)
        block(u"THEO TCVN 5574:2018 - THÉP THÂN, ĐAI CẤU TẠO, ĐAI BỔ SUNG", [
            (u"Thép thân (chống phình) cho dầm cao", self.ck_skin),
            (u"   khi h > (mm)", self.n_skh),
            (u"   khoảng cách tối đa (mm)", self.n_sks),
            (u"   Ø tối thiểu", self.n_skd),
            (u"   As mỗi thanh ≥ x % · s · max(b/2; 200)", self.n_skr),
            (u"Kẹp khoảng cách đai theo 10.3.4.3", self.ck_tst),
            (u"   a0 (mm): h0 = h - a0", self.n_a0),
            (u"Đai bổ sung chỗ dầm phụ gác lên (10.4.12)", self.ck_hang),
            (u"   bước đai bổ sung (mm)", self.n_hga),
            (u"Đai 4 nhánh khi b ≥ (mm)", self.n_legb),
            (u"   hoặc số thanh trong 1 lớp >", self.n_legn),
            (u"Đai: Ø tối thiểu (mm)  [B < 70: 6]", self.n_sdm),
            (u"Đai: trần a gần gối (mm)  [B < 70: 300]", self.n_sa1),
            (u"Đai: trần a giữa nhịp (mm)  [B < 70: 500]", self.n_sa2),
            (u"", pn_tv),
            (u"Áp dụng: thay thép thân 'TCVN thân' cũ (không đụng thép chủ / thép thân bạn tự nhập), "
             u"đặt đai cấu tạo nơi chưa có đai, kẹp bước đai về mức tối đa (chỉ giảm, không tăng), thêm đai trong khi 4 nhánh. "
             u"Đai gần gối: a ≤ min(0,5h0; trần 1), giữa nhịp: a ≤ min(0,75h0; trần 2) (làm tròn xuống bội 50), Ø ≥ Ø tối thiểu. "
             u"Mặc định 6 / 300 / 500 cho bê tông dưới B70; bê tông B70-B100 chặt hơn: tự nhập 3 ô trên theo tiêu chuẩn của dự án. "
             u"Đai bổ sung dầm phụ: đoạn b + 2h của DẦM PHỤ (cần quét lại để có cột 'h dầm đỡ'). "
             u"Thép thân khi h > 700: mục 10.4.13 (mỗi cạnh bên, s < 400, As ≥ 0,1%·s·max(b/2; 200)) - nguồn: tài liệu VIETCONS "
             u"(Nguyễn Đình Nghĩa) dẫn 10.4.13, CHƯA đối chiếu bản TCVN gốc: hãy kiểm lại với tiêu chuẩn của dự án. "
             u"Kết quả kiểm tra xem ở tab 'Kiểm tra TCVN'.", None)])
        self.c_ratio = mcombo(RATIOS, c['ratio'] if isinstance(c['ratio'], int) and c['ratio'] < len(RATIOS) else 0, 100)
        self.c_vex = mcombo(VEXS, c['vex'] if isinstance(c['vex'], int) and c['vex'] < len(VEXS) else 0, 100)
        self.ck_st = CheckBox()
        self.ck_st.Text = u"Hiện đai"
        self.ck_st.Checked = bool(c['show_stir'])
        self.ck_flip = CheckBox()
        self.ck_flip.Text = u"Đảo T/P mặt cắt"
        self.ck_flip.Checked = bool(c.get('flip', False))
        self.ck_flip.AutoSize = True
        self.ck_abs = CheckBox()
        self.ck_abs.Text = u"Cote tuyệt đối như Revit"
        self.ck_abs.Checked = bool(c.get('abs', True))
        self.ck_abs.AutoSize = True
        self.c_theme = mcombo([u"Sáng", u"Tối"], 1 if int(c.get('theme', 0)) == 1 else 0, 100)
        block(u"HIỂN THỊ", [(u"Giao diện", self.c_theme), (u"Tỉ lệ ngang", self.c_ratio), (u"Phóng đại đứng", self.c_vex),
                           (u"Đai", self.ck_st), (u"Mặt cắt", self.ck_flip), (u"Cote", self.ck_abs)])

        # --- tu bo tri theo tiet dien da quet
        ab = TableLayoutPanel()
        ab.AutoSize = True
        ab.AutoSizeMode = AutoSizeMode.GrowAndShrink
        ab.ColumnCount = 1
        ab.Margin = Padding(6)
        ab.Padding = Padding(6)
        ab.BorderStyle = BorderStyle.FixedSingle
        hd = Label()
        hd.Text = u"TỰ BỐ TRÍ THEO TIẾT DIỆN ĐÃ QUÉT"
        hd.AutoSize = True
        hd.Font = Font("Segoe UI", F(9), FontStyle.Bold)
        hd.Margin = Padding(3, 3, 3, 6)
        ab.Controls.Add(hd, 0, 0)
        r1 = FlowLayoutPanel()
        r1.AutoSize = True
        r1.WrapContents = False
        ab.Controls.Add(r1, 0, 1)

        def flab(parent, t):
            l_ = Label()
            l_.Text = t
            l_.AutoSize = True
            l_.Margin = Padding(8, 6, 3, 0)
            parent.Controls.Add(l_)
        flab(r1, u"Tiêu chí")
        self.c_crit = mcombo(CRITS, CKEYS.index(self.crit_key), 200)
        r1.Controls.Add(self.c_crit)
        flab(r1, u"Đầu thép trên")
        ends = [B.K_HET, B.K_GAP, B.K_NEO]
        self.c_end = mcombo(ends, ends.index(c['top_end']) if c['top_end'] in ends else 0, 150)
        r1.Controls.Add(self.c_end)
        self.ck_merge = CheckBox()
        self.ck_merge.Text = u"Nối liền các nhịp cùng loại thép"
        self.ck_merge.Checked = bool(c['merge'])
        self.ck_merge.AutoSize = True
        self.ck_merge.Margin = Padding(12, 4, 0, 0)
        r1.Controls.Add(self.ck_merge)
        r2 = FlowLayoutPanel()
        r2.AutoSize = True
        r2.WrapContents = False
        ab.Controls.Add(r2, 0, 2)
        for txt, w, fn in ((u"Tự bố trí dầm này", 150, lambda s_, e: self.on_auto(False)),
                           (u"Tự bố trí TẤT CẢ dầm của tầng", 220, lambda s_, e: self.on_auto(True)),
                           (u"Lấy lại tiết diện từ dữ liệu quét", 220, self.on_secrefresh)):
            b_ = Button()
            b_.Text, b_.Width, b_.Height = txt, w, 28
            if txt.startswith(u"Tự bố trí"):
                b_.Tag = 'primary'
            b_.Click += fn
            r2.Controls.Add(b_)
        nt = Label()
        nt.Text = (u"Mỗi dòng = 1 tiết diện b x h lấy từ dữ liệu quét (cột 'Quét được' cho biết số nhịp và khoảng L). "
                   u"Điền thép cho từng tiết diện (ví dụ 3T16), rồi bấm Tự bố trí. Thép gợi ý ban đầu lấy theo chiều cao h, bạn sửa lại.")
        nt.MaximumSize = Size(980, 0)
        nt.AutoSize = True
        nt.ForeColor = Color.FromArgb(110, 110, 110)
        nt.Margin = Padding(3, 6, 3, 3)
        ab.Controls.Add(nt, 0, 3)
        rg = self.rg = DataGridView()
        rg.Size = Size(990, 180)
        rg.AllowUserToAddRows = False
        rg.RowHeadersVisible = False
        for h, w in ((u"Tiết diện", 90), (u"Quét được", 170), (u"Thép trên", 85), (u"Thép dưới", 85), (u"TC gối trên", 85),
                     (u"TC nhịp dưới", 90), (u"Thép thân", 85), (u"Đai (Ø-a gối/a nhịp)", 130), (u"Đai trong", 90)):
            c_ = DataGridViewTextBoxColumn()
            c_.HeaderText, c_.Width = h, w
            c_.SortMode = DataGridViewColumnSortMode.NotSortable
            rg.Columns.Add(c_)
        ab.Controls.Add(rg, 0, 4)
        sf.Controls.Add(ab)
        self.fill_rules()

        # tab 4: huong dan
        gt = TextBox()
        gt.Multiline = True
        gt.ReadOnly = True
        gt.ScrollBars = ScrollBars.Vertical
        gt.Dock = DockStyle.Fill
        gt.Font = Font("Consolas", F(9))
        gt.Text = GUIDE.replace(u"\n", u"\r\n")
        p3.Controls.Add(gt)

        self.c_crit.SelectedIndexChanged += self.on_crit
        self.tc.SelectedIndexChanged += self.on_tab
        self.c_lvl.SelectedIndexChanged += self.on_lvl
        self.c_theme.SelectedIndexChanged += self.on_theme
        UI.apply(self.f, self.pal)
        self.cb.SelectedIndexChanged += self.on_combo
        f.KeyPreview = True
        f.KeyDown += self.on_form_key
        f.FormClosing += self.on_closing
        f.Shown += self.on_shown

    # ------------------------------------------------------------ quy tac tu bo tri
    def refresh_sections(self):
        """Lap bang quy tac theo tiet dien da quet (giu thep da gan cho cung tiet dien o cac tang khac)."""
        out = []
        for sc_ in self.m.sections():
            base = self.secmem.get((sc_['b'], sc_['h'])) or B.suggest_rule(sc_['h'])
            r = dict(base)
            r.update(b=sc_['b'], h=sc_['h'], count=sc_['count'], lmin=sc_['lmin'], lmax=sc_['lmax'])
            out.append(r)
        self.rules['s'] = out

    def fill_rules(self):
        k = self.crit_key
        sec = (k == 's')
        self.rg.Rows.Clear()
        self.rg.Columns[0].HeaderText = u"Tiết diện b x h" if sec else u"Từ ≥"
        self.rg.Columns[1].HeaderText = u"Quét được" if sec else u"Đến <"
        self.rg.Columns[0].ReadOnly = sec
        self.rg.Columns[1].ReadOnly = sec
        self.rg.Columns[0].Width = 100 if sec else 70
        self.rg.Columns[1].Width = 170 if sec else 70
        self.rg.AllowUserToAddRows = not sec
        for r in self.rules[k]:
            if sec:
                c0 = u"%dx%d" % (r['b'], r['h'])
                c1 = u"%d nhịp, L %d-%d mm" % (r['count'], r['lmin'], r['lmax'])
            else:
                c0, c1 = str(int(r.get('lo') or 0)), str(int(r.get('hi') or 0))
            self.rg.Rows.Add(Array[Object]([c0, c1, r.get('top', ''), r.get('bot', ''), r.get('tc_sup', ''),
                                           r.get('tc_span', ''), r.get('mid', ''), r.get('stir', ''), r.get('stir2', '')]))

    def read_rules(self):
        try:
            self.rg.EndEdit()
        except Exception:
            pass
        k = self.crit_key
        old = self.rules[k]
        out = []
        for i in range(self.rg.Rows.Count):
            row = self.rg.Rows[i]
            if row.IsNewRow:
                continue

            def t(c):
                v = row.Cells[c].Value
                return '' if v is None else str(v).strip()

            def fv(c):
                try:
                    return float(t(c))
                except Exception:
                    return 0.0
            fields = dict(top=t(2), bot=t(3), tc_sup=t(4), tc_span=t(5), mid=t(6), stir=t(7), stir2=t(8))
            if k == 's':
                base = dict(old[i]) if i < len(old) else {}
                base.update(fields)
                out.append(base)
                self.secmem[(int(base.get('b', 0)), int(base.get('h', 0)))] = dict(base)
            else:
                out.append(dict(lo=fv(0), hi=fv(1), **fields))
        self.rules[k] = out

    def on_crit(self, s, e):
        self.read_rules()
        self.crit_key = CKEYS[self.c_crit.SelectedIndex]
        if self.crit_key == 's':
            self.refresh_sections()
        self.fill_rules()

    def on_secrefresh(self, s, e):
        self.read_rules()
        self.refresh_sections()
        if self.crit_key != 's':
            self.c_crit.SelectedIndex = 0
        else:
            self.fill_rules()
        self.status.Text = u"Đã lấy %d tiết diện từ dữ liệu quét của tầng này." % len(self.rules['s'])

    def on_auto(self, all_):
        self.flush()
        self.read_rules()
        self.save_cfg_now()
        names = [n for n in self.names if n not in self.m.samples] if all_ else [self.cur]
        if not names:
            return
        has = [n for n in names if self.m.groups[n]]
        if has:
            r = MessageBox.Show(u"%d dầm đã có nhóm thép sẽ bị GHI ĐÈ bằng kết quả tự bố trí. Tiếp tục?" % len(has),
                                u"Tự bố trí", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            if r != DialogResult.Yes:
                return
        rules = self.rules[self.crit_key]
        merge, top_end = bool(self.ck_merge.Checked), str(self.c_end.SelectedItem)
        count = 0
        for nm in names:
            G, stirs = B.auto_layout(self.m.beam_data(nm), rules, self.crit_key, self.m.opt, merge, top_end)
            self.m.groups[nm] = G
            self.m.set_stir(nm, stirs)
            count += len(G)
        if any(n not in self.m.samples for n in names):
            self.dirty = True
        self.show(self.cur)
        self.busy = True
        for i, n in enumerate(self.names):
            self.cb.Items[i] = self.label(n)
        self.busy = False
        self.tc.SelectedIndex = 0
        self.status.Text = u"Đã tự bố trí %d nhóm thép cho %d dầm. Kiểm tra và chỉnh lại bằng bút hoặc bảng." % (count, len(names))

    def upd_tcsel(self):
        k = len([n for n in self.names if n in self.tc_sel and n not in self.m.samples])
        self.l_tcsel.Text = (u"Đã chọn %d dầm" % k) if k else u"Chưa chọn dầm nào"

    def on_tc_pick(self, s=None, e=None):
        free = [n for n in self.names if n not in self.m.samples]
        if not free:
            MessageBox.Show(u"Chưa có dầm nào trong tầng này.", u"Chọn dầm", MessageBoxButtons.OK, MessageBoxIcon.Information)
            return
        r = pick_beams(self.f, [(n, self.label(n)) for n in free], set(n for n in self.tc_sel if n in free), self.pal)
        if r is None:
            return
        self.tc_sel = set(r)
        self.c_tcscope.SelectedIndex = 3
        self.upd_tcsel()

    def on_tc_apply(self, s=None, e=None):
        self.flush()
        self.read_opts()
        self.upd_tcsel()
        if not B.tc_enabled(self.m.opt):
            MessageBox.Show(u"Chưa tick loại tăng cường nào (lớp 1 / lớp 2, trên / dưới).", u"Thép tăng cường",
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
            return
        sc = self.c_tcscope.SelectedIndex
        free = [n for n in self.names if n not in self.m.samples]
        if sc == 0:
            names = [self.cur] if self.cur else []
        elif sc == 1:
            names = [n for n in free if n in self.m.ticked]
        elif sc == 3:
            if not [n for n in free if n in self.tc_sel]:
                self.on_tc_pick()
            names = [n for n in free if n in self.tc_sel]
        else:
            names = free
        if not names:
            MessageBox.Show(u"Không có dầm nào để áp dụng (chưa tick dầm nào?).", u"Thép tăng cường",
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
            return
        if len(names) > 1:
            r = MessageBox.Show(u"Áp dụng thép tăng cường đã tick cho %d dầm? (tăng cường cũ cùng lớp / vị trí sẽ được thay)" % len(names),
                                u"Thép tăng cường", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            if r != DialogResult.Yes:
                return
        count = 0
        for nm in names:
            old = len(self.m.groups[nm])
            self.m.groups[nm] = B.apply_tc(self.m.beam_data(nm), self.m.groups[nm], self.m.opt)
            count += len(self.m.groups[nm]) - old
        if any(n not in self.m.samples for n in names):
            self.dirty = True
        self.show(self.cur)
        self.busy = True
        for i, n in enumerate(self.names):
            self.cb.Items[i] = self.label(n)
        self.busy = False
        self.tc.SelectedIndex = 0
        self.status.Text = u"Đã áp dụng thép tăng cường cho %d dầm (nhóm thép %+d). Kiểm tra và chỉnh lại bằng bút hoặc bảng." % (len(names), count)

    def on_tcvn_apply(self, all_):
        """Thep than (h > skin_h) + dai cau tao / kep dai / dai trong theo TCVN 5574:2018."""
        self.flush()
        self.read_opts()
        names = [n for n in self.names if n not in self.m.samples] if all_ else ([self.cur] if self.cur and self.cur not in self.m.samples else [])
        if not names:
            MessageBox.Show(u"Không có dầm để áp dụng (dầm mẫu không áp dụng được).", u"TCVN 5574:2018",
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
            return
        if len(names) > 1:
            r = MessageBox.Show(u"Áp dụng TCVN cho %d dầm? (thép thân 'TCVN thân' cũ được thay; đai chỉ bị kẹp về mức tối đa)" % len(names),
                                u"TCVN 5574:2018", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            if r != DialogResult.Yes:
                return
        o = self.m.opt
        n_skin = n_stir = 0
        for nm in names:
            bd = self.m.beam_data(nm)
            G = self.m.groups[nm]
            if o.get('skin_on'):
                old = len([g for g in G if B.is_skin(g)])
                G = B.apply_skin(bd, G, o)
                n_skin += len([g for g in G if B.is_skin(g)]) - old
                self.m.groups[nm] = G
            if o.get('tcvn_stir'):
                bd = self.m.beam_data(nm)
                new = B.tcvn_stirrups(bd, G, o)
                n_stir += sum(1 for x, y in zip(new, [(q['stir'], q['stir2']) for q in bd['spans']]) if tuple(x) != tuple(y))
                self.m.set_stir(nm, new)
        self.dirty = True
        self.show(self.cur)
        self.busy = True
        for i, n in enumerate(self.names):
            self.cb.Items[i] = self.label(n)
        self.busy = False
        self.refresh_tcvn()
        self.status.Text = u"TCVN: %d dầm - thép thân %+d nhóm, đai thay đổi ở %d nhịp. Xem tab 'Kiểm tra TCVN'." % (len(names), n_skin, n_stir)

    def refresh_tcvn(self):
        if self.cur is None:
            return
        try:
            if self.cur in self.m.samples:
                self.tv.Text = u"Dầm mẫu - không kiểm tra."
                return
            self.tv.Text = B.tcvn_report(self.m.beam_data(self.cur), self.m.groups[self.cur], self.m.opt)
        except Exception:
            self.tv.Text = u"Lỗi kiểm tra: " + traceback.format_exc().strip().splitlines()[-1]

    def on_tab(self, s, e):
        # tab Thiet lap / Huong dan can nhieu cho: keo khung duoi len; tab khac tra ve ti le cu
        try:
            if self.tc.SelectedIndex == 4:
                self.refresh_tcvn()
            h = int(self.sc.Height)
            if self.tc.SelectedIndex in (2, 3):
                self.sc.SplitterDistance = max(120, int(h * 0.22))
            else:
                self.sc.SplitterDistance = max(260, int(h * 0.62))
        except Exception:
            pass

    def on_shown(self, s, e):
        try:
            self.sc.SplitterDistance = max(260, int(self.sc.Height * 0.62))
        except Exception:
            pass
        if self.names:
            self.show(self.names[0])

    def label(self, n):
        tk = u"☑ " if n in self.m.ticked else u""
        if n in self.m.samples:
            return tk + u"%s  (không lưu - đổi tiết diện, lệch cote, sàn giật)" % n
        return tk + u"%s   (SL %s, %d nhịp, %d nhóm thép)" % (n, self.m.sl(n), len(self.m.beams[n]), len(self.m.groups[n]))

    def file_label(self, p):
        b = os.path.basename(p)
        b = b[:-5] if b.lower().endswith('.xlsx') else b
        return b[4:] if b.startswith('Dam_') else b

    def update_tick_ui(self):
        on = self.cur in self.m.ticked
        self.ck_tick.Checked = on
        self.ck_tick.Text = u"☑ Đã tick" if on else u"☐ Tick dầm"
        real = [n for n in self.names if n not in self.m.samples]
        self.tlab.Text = u"Đã tick %d/%d" % (len([n for n in real if n in self.m.ticked]), len(real))

    def on_tick_one(self, s, e):
        if self.cur is None:
            return
        if self.ck_tick.Checked:
            self.m.ticked.add(self.cur)
        else:
            self.m.ticked.discard(self.cur)
        if self.cur not in self.m.samples:
            self.dirty = True
        self.update_tick_ui()
        self.refresh_label()
        self.last = None

    def tick_all(self, flag):
        real = [n for n in self.names if n not in self.m.samples]
        if flag:
            self.m.ticked = set(real)
        else:
            self.m.ticked = set()
        self.dirty = self.dirty or bool(real)
        self.busy = True
        for i, n in enumerate(self.names):
            self.cb.Items[i] = self.label(n)
        self.busy = False
        self.update_tick_ui()
        self.last = None

    def refresh_results(self):
        """Cot 'Ket qua qua goi': thang / uon / neo tai tung goi theo nguong lech cao do."""
        if self.cur is None:
            return
        bd = self.m.beam_data(self.cur)
        gl = self.m.groups[self.cur]
        self.busy = True
        try:
            for r in range(min(self.g.Rows.Count, len(gl))):
                txt = B.cross_report(gl[r], bd, self.m.opt)
                cell = self.g.Rows[r].Cells[12]
                if (cell.Value or u'') != txt:
                    cell.Value = txt
        finally:
            self.busy = False

    # ------------------------------------------------------------ chuyen tang (moi tang 1 file Dam_<tang>.xlsx)
    def reselect_level(self):
        paths = [os.path.abspath(p_) for p_ in self.files]
        self.busy = True
        try:
            self.c_lvl.SelectedIndex = paths.index(os.path.abspath(self.m.path))
        except Exception:
            pass
        self.busy = False

    def on_lvl(self, s, e):
        if self.busy:
            return
        i = self.c_lvl.SelectedIndex
        if i < 0 or i >= len(self.files) or os.path.abspath(self.files[i]) == os.path.abspath(self.m.path):
            return
        self.switch_file(self.files[i])

    def switch_file(self, path):
        self.flush()
        if self.dirty:
            r = MessageBox.Show(u"Tầng hiện tại chưa lưu. Lưu trước khi chuyển tầng?", u"Chuyển tầng",
                                MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)
            if r == DialogResult.Cancel:
                self.reselect_level()
                return
            if r == DialogResult.Yes:
                try:
                    self.m.save()
                except Exception:
                    MessageBox.Show(u"Không ghi được file (đang mở trong Excel?).", u"Chuyển tầng")
                    self.reselect_level()
                    return
        try:
            m = R.Model(path)
        except Exception as ex:
            MessageBox.Show(str(ex), u"Chuyển tầng", MessageBoxButtons.OK, MessageBoxIcon.Error)
            self.reselect_level()
            return
        m.add_sample()
        self.m = m
        self.read_opts()                       # giu thiet lap dang chon tren giao dien
        self.names = list(m.beams.keys())
        self.cur = None
        self.dirty = False
        self.last = None
        self.f.Text = u"Thép dầm - " + os.path.basename(path)
        self.busy = True
        self.cb.Items.Clear()
        for n in self.names:
            self.cb.Items.Add(self.label(n))
        self.cb.SelectedIndex = 0
        self.busy = False
        self.refresh_sections()
        if self.crit_key == 's':
            self.fill_rules()
        self.show(self.names[0])
        self.update_tick_ui()
        self.status.Text = u"Đã mở tầng: " + self.file_label(path)

    # ------------------------------------------------------------ doc gia tri (ke ca o dang go)
    def ctext(self, grid, r, c):
        try:
            cur = grid.CurrentCell
            if (cur is not None and cur.RowIndex == r and cur.ColumnIndex == c and grid.IsCurrentCellInEditMode
                    and grid.EditingControl is not None):
                return str(grid.EditingControl.Text).strip()
        except Exception:
            pass
        v = grid.Rows[r].Cells[c].Value
        return '' if v is None else str(v).strip()

    def read_groups(self):
        gl = []
        for r in range(self.g.Rows.Count):
            def t(c):
                return self.ctext(self.g, r, c)

            def iv(c, d):
                try:
                    return int(float(t(c)))
                except Exception:
                    return d
            gl.append(dict(pos=t(1) or B.POS[1], layer=iv(2, 1), n=iv(3, 2), d=iv(4, 16), a=iv(5, 0),
                           lk=t(6) or B.K_NEO, lv=t(7), b=iv(8, 1), rk=t(9) or B.K_NEO, rv=t(10),
                           cross=t(11) or B.X_AUTO, note=t(13)))
        return gl

    def gap_text(self, v):
        return GAPS[0] if B.is_down(v) else str(v)

    def opt_gap(self):
        t = self.c_gap.Text.strip()
        return u'xuống' if (not t or t.startswith(u'Bằng dầm') or B.is_down(t)) else t

    def read_opts(self):
        o = self.m.opt
        o['cover'] = float(str(self.n_cov.Value))
        o['straight'] = float(str(self.n_str.Value))
        o['neo'] = self.t_neo.Text.strip() or u'30d'
        o['gap'] = self.opt_gap()
        o['ext'] = self.t_ext.Text.strip() or u'L/3'
        o['thr'] = float(str(self.n_thr.Value))
        o['slope'] = float(str(self.n_slp.Value))
        o['short'] = float(str(self.n_short.Value))
        o['zone_top'] = self.t_zt.Text.strip() or u'L/4'
        o['zone_bot'] = self.t_zb.Text.strip() or u'L/6'
        o['merge_on'] = 1.0 if self.ck_tcjoin.Checked else 0.0
        o['merge_gap'] = float(str(self.n_mgap.Value))
        o['near'] = float(str(self.n_near.Value))
        o['hook_clr'] = float(str(self.n_hclr.Value))
        o['pitch'] = float(str(self.n_pitch.Value))
        o['skin_on'] = 1.0 if self.ck_skin.Checked else 0.0
        o['skin_h'] = float(str(self.n_skh.Value))
        o['skin_s'] = float(str(self.n_sks.Value))
        o['skin_d'] = float(str(self.n_skd.Value))
        o['skin_ratio'] = float(str(self.n_skr.Value))
        o['tcvn_stir'] = 1.0 if self.ck_tst.Checked else 0.0
        o['stir_a0'] = float(str(self.n_a0.Value))
        o['hang_on'] = 1.0 if self.ck_hang.Checked else 0.0
        o['hang_a'] = float(str(self.n_hga.Value))
        o['leg_b'] = float(str(self.n_legb.Value))
        o['leg_n'] = float(str(self.n_legn.Value))
        o['stir_dmin'] = float(str(self.n_sdm.Value))
        o['stir_a1'] = float(str(self.n_sa1.Value))
        o['stir_a2'] = float(str(self.n_sa2.Value))
        for key, (ck_, nn_, cb_) in self.tcw.items():
            o[key + '_on'] = 1.0 if ck_.Checked else 0.0
            o[key + '_n'] = float(str(nn_.Value))
            o[key + '_d'] = float(TC_D_VALS[max(0, cb_.SelectedIndex)])

    def apply(self):
        if self.cur is None:
            return False
        ch = False
        gl = self.read_groups()
        if gl != self.m.groups[self.cur]:
            self.m.groups[self.cur] = gl
            ch = True
        st = [(self.ctext(self.s, r, 3), self.ctext(self.s, r, 4)) for r in range(self.s.Rows.Count)]
        old = [(x['stir'], x['stir2']) for x in self.m.beam_data(self.cur)['spans']]
        if st != old:
            self.m.set_stir(self.cur, st)
            ch = True
        before = dict(self.m.opt)
        self.read_opts()
        if before != self.m.opt:
            ch = True
        if ch and self.cur not in self.m.samples:
            self.dirty = True
        return ch

    def flush(self):
        try:
            self.g.EndEdit()
            self.s.EndEdit()
        except Exception:
            pass
        self.apply()

    # ------------------------------------------------------------ hien thi
    def show(self, name):
        self.busy = True
        self.cur = name
        self.g.Rows.Clear()
        self.s.Rows.Clear()
        bd = self.m.beam_data(name)
        for i, gr in enumerate(self.m.groups[name], 1):
            self.g.Rows.Add(Array[Object]([str(i), gr['pos'], str(gr['layer']), str(gr['n']), str(gr['d']),
                                          str(gr['a']), gr['lk'], gr['lv'], str(gr['b']), gr['rk'], gr['rv'],
                                          gr['cross'], '', gr['note']]))
        for sp in bd['spans']:
            self.s.Rows.Add(Array[Object]([str(sp['idx']), str(round(sp['clear'])),
                                          u'%dx%d' % (round(sp['b']), round(sp['h'])), sp['stir'], sp['stir2']]))
        self.busy = False
        ns = len(bd['spans'])
        try:
            self.n_k.Maximum = Decimal(max(ns + 1, 1))
        except Exception:
            pass
        self.info.Text = u"Dầm %s: SL = %s, %d nhịp, gối G0..G%d   [%d/%d]" % (
            name, self.m.sl(name), ns, ns, self.names.index(name) + 1, len(self.names))
        self.last = None
        self.fill_zones()
        self.refresh_results()
        self.update_tick_ui()
        try:
            if self.tc.SelectedIndex == 4:
                self.refresh_tcvn()
        except Exception:
            pass

    def check_row(self, r):
        ns = len(self.m.beams[self.cur])

        def ok(c, good):
            self.g.Rows[r].Cells[c].Style.BackColor = OKC if good else BAD

        def val(c):
            try:
                return int(float(self.ctext(self.g, r, c)))
            except Exception:
                return None
        for c, lo, hi in ((2, 1, 6), (3, 1, 30), (4, 6, 50)):
            v = val(c)
            ok(c, v is not None and lo <= v <= hi)
        a, b = val(5), val(8)
        a_ok = a is not None and 0 <= a <= ns
        b_ok = b is not None and 0 <= b <= ns
        if a_ok and b_ok and a > b:
            a_ok = b_ok = False
        ok(5, a_ok)
        ok(8, b_ok)
        ok(7, B.len_valid(self.ctext(self.g, r, 7)))
        ok(10, B.len_valid(self.ctext(self.g, r, 10)))

    def sel_row(self):
        try:
            if self.tc.SelectedIndex == 0 and self.g.CurrentCell is not None:
                return self.g.CurrentCell.RowIndex
        except Exception:
            pass
        return -1

    def view(self):
        tab = self.tc.SelectedIndex
        sel = span = None
        try:
            if self.g.CurrentCell is not None and tab == 0:
                sel = self.g.CurrentCell.RowIndex
            if tab == 1 and self.s.CurrentCell is not None:
                span = self.s.CurrentCell.RowIndex
        except Exception:
            pass
        ri, vi, di = self.c_ratio.SelectedIndex, self.c_vex.SelectedIndex, self.c_dim.SelectedIndex
        cw, ch = self.pan.ClientSize.Width, self.pan.ClientSize.Height
        return dict(ratio=0 if ri <= 0 else int(RATIOS[ri].split(':')[1]), vex=0 if vi <= 0 else int(VEXS[vi][:-1]),
                    stir=bool(self.ck_st.Checked), sel=sel, span=span, Wfit=max(cw - 4, 600), H=max(ch - 4, 300),
                    dims={0: 1, 1: 2, 2: 0}.get(di, 1), flip=bool(self.ck_flip.Checked), vm=self.c_view.SelectedIndex,
                    absc=bool(self.ck_abs.Checked))

    def signature(self):
        v = self.view()
        parts = [self.cur, v['sel'], v['span'], v['Wfit'], v['H'], v['ratio'], v['vex'], v['stir'], v['dims'],
                 self.n_cov.Value, self.n_str.Value, self.t_neo.Text, self.c_gap.Text, self.t_ext.Text,
                 self.n_thr.Value, self.n_slp.Value, self.n_short.Value, self.t_zt.Text, self.t_zb.Text,
                 self.ck_tcjoin.Checked, self.n_mgap.Value, self.n_near.Value, self.n_hclr.Value, self.n_pitch.Value,
                 self.ck_skin.Checked, self.n_skh.Value, self.n_sks.Value, self.n_skd.Value, self.n_skr.Value,
                 self.ck_tst.Checked, self.n_a0.Value, self.ck_hang.Checked, self.n_hga.Value, self.n_legb.Value, self.n_legn.Value,
                 self.n_sdm.Value, self.n_sa1.Value, self.n_sa2.Value,
                 v['flip'], v['absc'], v['vm'], self.ck_hint.Checked, u','.join(sorted(self.m.ticked)), self.g.Rows.Count, self.s.Rows.Count,
                 len(self.m.zones.get(self.cur, [])), self.m.geo_ver]
        for r in range(self.g.Rows.Count):
            parts.extend(self.ctext(self.g, r, c) for c in range(1, 12))
            parts.append(self.ctext(self.g, r, 13))
        for r in range(self.s.Rows.Count):
            parts.append(self.ctext(self.s, r, 3))
            parts.append(self.ctext(self.s, r, 4))
        return u'|'.join(str(p) for p in parts)

    def redraw(self):
        v = self.view()
        vm = v['vm']
        if vm == 0:
            bd = self.m.beam_data(self.cur)
            prims, W, ctx = D.render(bd, self.m.groups[self.cur], self.m.opt, v)
        else:
            names = [self.cur] if vm == 1 else [n for n in self.names if n in self.m.ticked]
            items = [(self.m.beam_data(n), self.m.groups[n]) for n in names]
            if items:
                prims, W, ctx = D.render_sections(items, self.m.opt, v)
            else:
                prims = [('text', 14, 14, u'Chưa tick dầm nào: bấm "☐ Tick dầm" ở thanh trên (hoặc "Tick hết") rồi chọn lại chế độ xem này.',
                          (110, 110, 110), 11, 'l', False)]
                W, ctx = v['Wfit'], dict(ml=0, oy=0, kx=1, ky=1, H=int(v['H']), lay=None)
        self.ctx = ctx
        W, H = int(W), int(ctx['H'])
        bmp = paint(prims, W, H)
        self.hover_key = None
        if self.ck_hint.Checked and self.cur not in self.m.samples and ctx.get('dims'):
            paint_on(bmp, [('rect', d['x0'], d['y0'], d['x1'] - d['x0'], d['y1'] - d['y0'], None, (236, 196, 110)) for d in ctx['dims']])
        old_b, old_p = self.base, self.prev_img
        self.base, self.prev_img = bmp, None
        self.pb.Size = Size(W, H)
        self.pb.Image = bmp
        for o in (old_b, old_p):
            if o is not None:
                o.Dispose()

    def on_tick(self, s, e):
        if self.cur is None or self.busy or self.stroke is not None or self.drag is not None:
            return
        try:
            sig = self.signature()
            if sig == self.last:
                return
            self.last = sig
            self.apply()
            for r in range(self.g.Rows.Count):
                self.check_row(r)
            self.fill_zones()
            self.refresh_results()
            self.redraw()
            if self.tc.SelectedIndex == 4:
                self.refresh_tcvn()
        except Exception:
            err = traceback.format_exc()
            self.status.Text = u"Lỗi vẽ: " + err.strip().splitlines()[-1]
            try:
                if not os.path.isdir(DIR):
                    os.makedirs(DIR)
                open(os.path.join(DIR, 'error.log'), 'a', encoding='utf-8').write(err + '\n')
            except Exception:
                pass

    # ------------------------------------------------------------ but ve / chon thep
    def set_tool(self, t):
        self.tool = t
        self.b_sel.Checked = (t == 'sel')
        self.b_pen.Checked = (t == 'pen')
        self.b_stir.Checked = (t == 'stir')
        self.pb.Cursor = Cursors.Cross if t in ('pen', 'stir') else Cursors.Default
        self.status.Text = {
            'pen': u"Vẽ thép: kéo chuột từ đầu đến cuối thanh. Ở cột, kéo thẳng xuống (thép dưới: lên) = đầu gập vào cột.",
            'stir': u"Vẽ đai: chọn Ø và a ở thanh công cụ, kéo ngang từ điểm đầu đến điểm cuối vùng đai.",
            'sel': u"Chọn / sửa: bấm vào thanh thép, kéo ô vuông ở đầu để đổi chiều dài. Bấm vào SỐ DIM để sửa ngay (Enter / Tab sang số kế tiếp)."}[t]

    def to_mm(self, px, py):
        c = self.ctx
        return (px - c['ml']) / c['kx'], (py - c['oy']) / c['ky']

    def lines_px(self, gi):
        c = self.ctx
        g = self.m.groups[self.cur][gi]
        lines = B.build(g, self.m.beam_data(self.cur), self.m.opt, c['lay'])
        return [[(c['ml'] + x * c['kx'], c['oy'] + y * c['ky']) for x, y in q] for q in lines]

    def hit_group(self, px, py):
        best = None
        for gi in range(len(self.m.groups[self.cur])):
            for q in self.lines_px(gi):
                for a, b in zip(q[:-1], q[1:]):
                    d = seg_dist(px, py, a, b)
                    if d <= 6.0 and (best is None or d < best[0]):
                        best = (d, gi)
        return best[1] if best else None

    def hit_handle(self, px, py):
        gi = self.sel_row()
        gl = self.m.groups[self.cur]
        if not (0 <= gi < len(gl)) or B.K_UON in (gl[gi]['lk'], gl[gi]['rk']):
            return None
        q = self.lines_px(gi)
        if not q:
            return None
        for side, p in (('L', q[0][0]), ('R', q[-1][-1])):
            if math.hypot(px - p[0], py - p[1]) <= 10.0:
                return (gi, side)
        return None

    def select_group(self, gi):
        """Chon thep tren dam -> bang chi tiet thep nhay den dong do, to mau ca dong va cuon vao tam nhin."""
        self.tc.SelectedIndex = 0
        g = self.g
        try:
            g.ClearSelection()
            g.CurrentCell = g.Rows[gi].Cells[1]
            g.Rows[gi].Selected = True
        except Exception:
            pass
        try:
            row = g.Rows[gi]
            if not row.Displayed:                       # dong dang nam ngoai vung nhin thay -> cuon toi
                g.FirstDisplayedScrollingRowIndex = max(0, gi - 1)
        except Exception:
            pass
        try:
            self.status.Text = u"Đã chọn dòng %d: %s" % (gi + 1, self.gtext(self.m.groups[self.cur][gi]))
        except Exception:
            pass
        self.last = None

    def stroke_mm(self, stroke):
        pts = []
        for i, p in enumerate(stroke):
            if i == 0:
                pts.append(self.to_mm(*p))
                continue
            a, b = stroke[i - 1], p
            n = max(int(math.hypot(b[0] - a[0], b[1] - a[1]) // 5), 1)
            for k in range(1, n + 1):
                pts.append(self.to_mm(a[0] + (b[0] - a[0]) * k / float(n), a[1] + (b[1] - a[1]) * k / float(n)))
        return pts

    def infer_stroke(self):
        if not self.stroke or len(self.stroke) < 2:
            return None
        li = self.c_lay.SelectedIndex
        return B.infer_group(self.m.beam_data(self.cur), self.m.opt, self.stroke_mm(self.stroke),
                             int(str(self.n_pn.Value)), int(str(self.n_pd.Value)), bool(self.ck_hook.Checked),
                             self.c_snap.SelectedIndex == 0, 0 if li == 0 else li)

    def stir_zone(self):
        """Vung dai tu net keo ngang: (x0, x1) mm, hut vao mep goi / 1/4 / 1/2 nhip."""
        if not self.stroke or len(self.stroke) < 2:
            return None
        bd = self.m.beam_data(self.cur)
        tol = 14.0 / self.ctx['kx']
        x0 = B.snap_x(bd, self.to_mm(*self.stroke[0])[0], tol)
        x1 = B.snap_x(bd, self.to_mm(*self.stroke[-1])[0], tol)
        if abs(x1 - x0) < 150.0:
            return None
        return (min(x0, x1), max(x0, x1))

    def gtext(self, g):
        return u"%dØ%d %s lớp %d:  G%d [%s %s]  →  G%d [%s %s]" % (
            g['n'], g['d'], g['pos'], g['layer'], g['a'], g['lk'], g['lv'], g['b'], g['rk'], g['rv'])

    def draw_preview(self, extra=None):
        if self.base is None:
            return
        clone = Bitmap(self.base)
        prims = []
        if self.stroke:
            if self.tool == 'stir':
                y = self.stroke[0][1]
                prims.append(('line', self.stroke[0][0], y, self.stroke[-1][0], y, D.C_STIR, 4, False))
                for p in (self.stroke[0], self.stroke[-1]):
                    prims.append(('line', p[0], y - 14, p[0], y + 14, D.C_STIR, 2, False))
            else:
                wd = max(3.0, int(str(self.n_pd.Value)) * 0.2 + 2.0)
                for a, b in zip(self.stroke[:-1], self.stroke[1:]):
                    prims.append(('line', a[0], a[1], b[0], b[1], D.C_SEL, wd, False))
                prims.append(('circle', self.stroke[0][0], self.stroke[0][1], 5, (255, 255, 255), D.C_SEL))
        if extra:
            prims.extend(extra)
        paint_on(clone, prims)
        old = self.prev_img
        self.prev_img = clone
        self.pb.Image = clone
        if old is not None:
            old.Dispose()

    def on_md(self, s, e):
        if self.cur is None or self.ctx is None or self.ctx.get('lay') is None or e.Button != MouseButtons.Left:
            return
        self.flush()
        if self.inl.click(e.X, e.Y, self.tool == 'sel'):      # bam vao so dim -> mo o nhap tai cho
            return
        if self.tool in ('pen', 'stir'):
            self.stroke = [(e.X, e.Y)]
            return
        h = self.hit_handle(e.X, e.Y)
        if h is not None:
            self.drag = h
            return
        gi = self.hit_group(e.X, e.Y)
        if gi is not None:
            self.select_group(gi)

    def hit_dim(self, px, py):
        best = None
        for d in (self.ctx or {}).get('dims') or []:
            if d['x0'] <= px <= d['x1'] and d['y0'] <= py <= d['y1']:
                area = (d['x1'] - d['x0']) * (d['y1'] - d['y0'])
                if best is None or area < best[0]:
                    best = (area, d)
        return best[1] if best else None

    def after_dim(self, msg):
        self.dirty = True
        self.show(self.cur)
        self.busy = True
        for i, n in enumerate(self.names):
            self.cb.Items[i] = self.label(n)
        self.busy = False
        self.last = None
        self.status.Text = msg + u"   (đã đổi trong bộ nhớ - nhớ bấm Lưu; nút ↶ để hoàn tác)"

    def on_dbl(self, s, e):
        return                      # da thay bang sua truc tiep (bm_dimtab.InlineEdit): bam 1 lan vao so dim
        if (e.Button != MouseButtons.Left or self.tool != 'sel' or self.cur is None or self.ctx is None
                or self.ctx.get('lay') is None):
            return
        d = self.hit_dim(e.X, e.Y)
        if d is None:
            return
        if self.cur in self.m.samples:
            MessageBox.Show(u"Dầm mẫu hướng dẫn không sửa kích thước được.", u"Sửa kích thước", MessageBoxButtons.OK, MessageBoxIcon.Information)
            return
        self.flush()
        val = ask_value(self.f, u"Sửa kích thước", d['title'], d['cur'], self.pal, bool(d.get('text')))
        if val is None:
            return
        ok, msg = self.m.set_dim(self.cur, d['key'], val)
        if not ok:
            MessageBox.Show(msg, u"Sửa kích thước", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            return
        self.after_dim(msg)

    def on_dimundo(self, s=None, e=None):
        if not self.cur or self.cur in self.m.samples:
            return
        self.flush()
        if self.m.undo_dim(self.cur) is None:
            self.status.Text = u"Không có thay đổi kích thước nào để hoàn tác ở dầm này."
            return
        self.after_dim(u"Đã hoàn tác 1 lần sửa kích thước.")

    def on_dimredo(self, s=None, e=None):
        if not self.cur or self.cur in self.m.samples:
            return
        self.flush()
        if self.m.redo_dim(self.cur) is None:
            self.status.Text = u"Không có thay đổi nào để làm lại ở dầm này."
            return
        self.after_dim(u"Đã làm lại 1 lần sửa kích thước.")

    def on_form_key(self, s, e):
        """Ctrl+Z / Ctrl+Y hoan tac / lam lai khi KHONG dang go trong 1 o nhap (o dim, bang, so, combo tu xu ly rieng)."""
        try:
            from System.Windows.Forms import Keys
            if not e.Control or e.Alt or e.KeyCode not in (Keys.Z, Keys.Y):
                return
            if self.inl.active or self.g.IsCurrentCellInEditMode or self.s.IsCurrentCellInEditMode or self.zg.IsCurrentCellInEditMode:
                return
            ac = self.f.ActiveControl
            while ac is not None and hasattr(ac, 'ActiveControl') and ac.ActiveControl is not None and ac.ActiveControl is not ac:
                ac = ac.ActiveControl
            if ac is not None and ac.GetType().Name in ('TextBox', 'UpDownEdit', 'NumericUpDown', 'ComboBox'):
                return
            e.Handled = e.SuppressKeyPress = True
            if e.KeyCode == Keys.Z:
                self.on_dimundo()
            else:
                self.on_dimredo()
        except Exception:
            pass

    def on_mm(self, s, e):
        if self.stroke is None and self.drag is None and self.tool == 'sel':
            try:
                hd = self.hit_dim(e.X, e.Y)
                self.pb.Cursor = Cursors.Hand if hd is not None else Cursors.Default
                hk = hd['key'] if hd is not None else None
                if hk != self.hover_key and not self.inl.active:       # vien cam o dang tro chuot, status = y nghia o do
                    self.hover_key = hk
                    if hd is not None:
                        self.status.Text = hd.get('title') or u''
                        self.draw_preview([('rect', hd['x0'], hd['y0'], hd['x1'] - hd['x0'], hd['y1'] - hd['y0'], None, D.C_SEL)])
                    else:
                        self.draw_preview()
            except Exception:
                pass
        if self.stroke is not None:
            a = self.stroke[-1]
            if (e.X - a[0]) ** 2 + (e.Y - a[1]) ** 2 >= 9:
                self.stroke.append((e.X, e.Y))
                if self.tool == 'stir':
                    z = self.stir_zone()
                    self.status.Text = (u"→ Vùng đai Ø%d a%d, từ %d đến %d mm (dài %d)" % (
                        int(str(self.n_sd.Value)), int(str(self.n_sa.Value)), z[0], z[1], z[1] - z[0])) if z else u"Kéo thêm để chọn vùng đai..."
                else:
                    g = self.infer_stroke()
                    self.status.Text = (u"→ " + self.gtext(g)) if g else u"Kéo thêm để vẽ thanh thép..."
                self.draw_preview()
        elif self.drag is not None:
            gi, side = self.drag
            xm = self.to_mm(e.X, e.Y)[0]
            ng = B.retarget(self.m.groups[self.cur][gi], self.m.beam_data(self.cur), self.m.opt, side, xm)
            self.status.Text = (u"→ " + self.gtext(ng)) if ng else u"Không đổi được đầu thép ở vị trí này."
            self.draw_preview([('line', e.X, 84, e.X, self.ctx['H'] - 30, D.C_SEL, 1, True)])

    def on_mu(self, s, e):
        if e.Button != MouseButtons.Left:
            return
        try:
            if self.stroke is not None and self.tool == 'stir':
                z = self.stir_zone()
                self.stroke = None
                if z is None:
                    self.status.Text = u"Vùng đai quá ngắn - kéo lại."
                    self.draw_preview()
                    return
                d, a = int(str(self.n_sd.Value)), int(str(self.n_sa.Value))
                self.m.add_zone(self.cur, z[0], z[1], d, a)
                if self.cur not in self.m.samples:
                    self.dirty = True
                self.last = None
                self.fill_zones()
                self.status.Text = u"Đã vẽ vùng đai Ø%d a%d từ %d đến %d mm." % (d, a, z[0], z[1])
            elif self.stroke is not None:
                g = self.infer_stroke()
                self.stroke = None
                if g is None:
                    self.status.Text = u"Nét vẽ quá ngắn hoặc nằm ngoài dầm - vẽ lại."
                    self.draw_preview()
                    return
                self.m.groups[self.cur].append(g)
                if self.cur not in self.m.samples:
                    self.dirty = True
                self.show(self.cur)
                self.select_group(len(self.m.groups[self.cur]) - 1)
                self.refresh_label()
                self.status.Text = u"Đã vẽ: " + self.gtext(g)
            elif self.drag is not None:
                gi, side = self.drag
                self.drag = None
                xm = self.to_mm(e.X, e.Y)[0]
                ng = B.retarget(self.m.groups[self.cur][gi], self.m.beam_data(self.cur), self.m.opt, side, xm)
                if ng is None:
                    self.status.Text = u"Không đổi được đầu thép ở vị trí này."
                    self.last = None
                    return
                self.m.groups[self.cur][gi] = ng
                if self.cur not in self.m.samples:
                    self.dirty = True
                self.show(self.cur)
                self.select_group(gi)
                self.status.Text = u"Đã sửa: " + self.gtext(ng)
        except Exception:
            self.stroke = self.drag = None
            self.status.Text = u"Lỗi bút vẽ: " + traceback.format_exc().strip().splitlines()[-1]
            self.last = None

    # ------------------------------------------------------------ vung dai
    def fill_zones(self):
        if self.cur is None:
            return
        self.zg.Rows.Clear()
        for z in self.m.beam_data(self.cur)['zones']:
            self.zg.Rows.Add(Array[Object]([str(round(z['x0'])), str(round(z['x1'])), str(z['d']), str(z['a']),
                                           str(max(int(round((z['x1'] - z['x0']) / float(z['a']))), 1)),
                                           str(round(z['x1'] - z['x0']))]))
        self.zlab.Text = u"Vùng vẽ tay: %d" % len(self.m.zones.get(self.cur, []))

    def on_zundo(self, s, e):
        if self.cur and self.m.undo_zone(self.cur):
            if self.cur not in self.m.samples:
                self.dirty = True
            self.last = None
            self.fill_zones()

    def on_zclear(self, s, e):
        if self.cur and self.m.zones.get(self.cur):
            self.m.clear_zones(self.cur)
            if self.cur not in self.m.samples:
                self.dirty = True
            self.last = None
            self.fill_zones()

    # ------------------------------------------------------------ su kien nut
    def on_dataerr(self, s, e):
        e.ThrowException = False

    def on_dirty(self, s, e):
        try:
            if self.g.IsCurrentCellDirty:
                self.g.CommitEdit(DataGridViewDataErrorContexts.Commit)
        except Exception:
            pass

    def on_combo(self, s, e):
        if self.busy or self.cb.SelectedIndex < 0:
            return
        self.flush()
        self.show(self.names[self.cb.SelectedIndex])
        self.sync_revit()

    def step(self, d):
        i = self.cb.SelectedIndex + d
        if 0 <= i < len(self.names):
            self.cb.SelectedIndex = i

    def refresh_label(self):
        self.busy = True
        self.cb.Items[self.cb.SelectedIndex] = self.label(self.cur)
        self.busy = False

    def save_cfg_now(self):
        self.read_rules()
        c = dict(ratio=self.c_ratio.SelectedIndex, vex=self.c_vex.SelectedIndex, show_stir=bool(self.ck_st.Checked),
                 dims=self.c_dim.SelectedIndex, crit=self.c_crit.SelectedIndex, merge=bool(self.ck_merge.Checked),
                 flip=bool(self.ck_flip.Checked), abs=bool(self.ck_abs.Checked), view=self.c_view.SelectedIndex,
                 theme=self.c_theme.SelectedIndex,
                 top_end=str(self.c_end.SelectedItem), rules={'h': self.rules['h'], 'l': self.rules['l']},
                 secmem=[dict(v_) for v_ in self.secmem.values()])
        self.cfg = c
        save_cfg(c)

    def add_group(self, gr):
        self.flush()
        self.m.groups[self.cur].append(gr)
        if self.cur not in self.m.samples:
            self.dirty = True
        self.show(self.cur)
        self.select_group(len(self.m.groups[self.cur]) - 1)
        self.refresh_label()

    def on_add(self, s, e):
        self.add_group(B.new_group(pos=B.POS[0], layer=2, n=2, d=16, a=0, b=len(self.m.beams[self.cur])))

    def on_dup(self, s, e):
        self.flush()
        r = self.sel_row()
        if 0 <= r < len(self.m.groups[self.cur]):
            self.add_group(dict(self.m.groups[self.cur][r]))

    def on_del(self, s, e):
        self.flush()
        r = self.sel_row()
        if 0 <= r < len(self.m.groups[self.cur]):
            del self.m.groups[self.cur][r]
            if self.cur not in self.m.samples:
                self.dirty = True
            self.show(self.cur)
            self.refresh_label()

    def msg(self, t):
        self.status.Text = t

    def on_tpl(self, s, e):
        self.flush()
        ns = len(self.m.beams[self.cur])
        k = int(float(str(self.n_k.Value)))
        t = self.c_tpl.SelectedIndex
        P0, P1, PM = B.POS
        gap = self.opt_gap()
        if t == 0:
            g = B.new_group(pos=P0, layer=1, n=3, d=16, a=0, b=ns, lk=B.K_HET, rk=B.K_HET)
        elif t in (2, 3):
            if not 0 <= k <= ns:
                return self.msg(u"Gối số phải từ 0 đến %d." % ns)
            if t == 2:
                g = B.new_group(pos=P0, layer=2, n=2, d=16, a=k, b=k, lk=B.K_EXT, rk=B.K_EXT)
                if k == 0:
                    g['lk'] = B.K_HET
                if k == ns:
                    g['rk'] = B.K_HET
            else:
                if k not in (0, ns):
                    return self.msg(u"Mẫu này dùng cho gối đầu: nhập gối số 0 hoặc %d." % ns)
                g = B.new_group(pos=P0, layer=2, n=2, d=16, a=k, b=k, lk=B.K_GAP if k == 0 else B.K_EXT,
                                rk=B.K_EXT if k == 0 else B.K_GAP, lv=gap if k == 0 else '', rv='' if k == 0 else gap)
        else:
            if not 1 <= k <= ns:
                return self.msg(u"Nhịp số phải từ 1 đến %d (nhịp N1 nằm giữa gối G0 và G1)." % ns)
            k -= 1
            if t == 1:
                g = B.new_group(pos=P1, layer=1, n=3, d=16, a=k, b=k + 1, lk=B.K_NEO, rk=B.K_NEO)
            elif t == 4:
                g = B.new_group(pos=P0, layer=2, n=2, d=16, a=k, b=k + 1, lk=B.K_CUT, lv='L/4', rk=B.K_CUT, rv='L/4')
            elif t == 5:
                g = B.new_group(pos=P1, layer=2, n=2, d=16, a=k, b=k + 1, lk=B.K_CUT, lv='L/6', rk=B.K_CUT, rv='L/6')
            elif t == 6:
                g = B.new_group(pos=P1, layer=1, n=1, d=16, a=k, b=k + 1, lk=B.K_NEO, rk=B.K_UON, rv='L/6;L/4')
            elif t == 7:
                g = B.new_group(pos=P1, layer=1, n=1, d=16, a=k, b=k + 1, lk=B.K_UON, lv='L/6;L/4', rk=B.K_NEO)
            elif t == 8:
                g = B.new_group(pos=P0, layer=2, n=2, d=12, a=k, b=k + 1, lk=B.K_CUT, lv='L/5', rk=B.K_CUT, rv='L/5')
            else:
                g = B.new_group(pos=PM, layer=1, n=2, d=12, a=k, b=k + 1, lk=B.K_NEO, rk=B.K_NEO)
        self.add_group(g)

    def on_save(self, s, e):
        self.flush()
        self.save_cfg_now()
        try:
            self.m.save()
        except PermissionError:
            MessageBox.Show(u"Không ghi được file. Hãy đóng file Excel đang mở rồi Lưu lại.", u"Thép dầm")
            return
        self.dirty = False
        bad = self.m.problems()
        msg = u"Đã lưu: " + self.m.path
        if bad:
            msg += u"\n\nCó %d vấn đề, ví dụ: dầm %s, nhóm %s: %s" % (len(bad), bad[0][0], bad[0][1], bad[0][2])
        self.status.Text = msg.split(u"\n")[0]
        MessageBox.Show(msg, u"Thép dầm", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning if bad else MessageBoxIcon.Information)

    def on_closing(self, s, e):
        self.flush()
        if self.dirty:
            r = MessageBox.Show(u"Chưa lưu thay đổi. Lưu vào Excel trước khi đóng?", u"Thép dầm",
                                MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)
            if r == DialogResult.Cancel:
                e.Cancel = True
                return
            if r == DialogResult.Yes:
                try:
                    self.m.save()
                except Exception:
                    MessageBox.Show(u"Không ghi được file (đang mở trong Excel?).", u"Thép dầm")
                    e.Cancel = True
                    return
        self.timer.Stop()
        self.save_cfg_now()

    # ------------------------------------------------------------ giao dien sang / toi
    def on_theme(self, s, e):
        self.pal = UI.DARK if self.c_theme.SelectedIndex == 1 else UI.LIGHT
        UI.apply(self.f, self.pal)
        self.last = None

    # ------------------------------------------------------------ cau noi Revit (cua so khong chan Revit)
    def revit_select(self, zoom=True):
        if not self.runner:
            self.status.Text = u"Không kết nối được Revit (ExternalEvent) - xem Documents\\BeamRebar\\error.log."
            return
        ids = self.m.ids.get(self.cur) or []
        if not ids:
            self.status.Text = u"Dầm này không có ElementId Revit (dầm mẫu hoặc file quét cũ)."
            return
        self.runner.run(_revit_select_job, self, list(ids), zoom)

    def revit_pull(self):
        if not self.runner:
            self.status.Text = u"Không kết nối được Revit (ExternalEvent)."
            return
        self.runner.run(_revit_pull_job, self)

    def on_revit_ids(self, ids):
        s_ = set(ids)
        if not s_:
            self.status.Text = u"Chưa chọn đối tượng nào trong Revit."
            return
        for n in self.names:
            if n not in self.m.samples and s_ & set(self.m.ids.get(n, [])):
                self.cb.SelectedIndex = self.names.index(n)
                self.status.Text = u"Đã chọn dầm %s theo đối tượng đang chọn trong Revit." % n
                return
        self.status.Text = u"Đối tượng đang chọn không thuộc tầng này - thử đổi ô Tầng."

    def sync_revit(self):
        if self.runner and self.ck_sync.Checked and self.cur and self.cur not in self.m.samples:
            self.revit_select(False)

    def on_closed(self, s, e):
        try:
            self.timer.Stop()
        except Exception:
            pass
        if getattr(builtins, '_bm_editor', None) is self:
            builtins._bm_editor = None

    def run(self):
        """Hien cua so KHONG CHAN (modeless): van thao tac duoc mo hinh Revit khi tool dang mo."""
        self.f.FormClosed += self.on_closed
        builtins._bm_editor = self                    # giu tham chieu song sau khi lenh pyRevit ket thuc
        owner = bm_revit.owner_window()
        try:
            if owner is not None:
                self.f.Show(owner)
            else:
                self.f.Show()
        except Exception:
            self.f.Show()


def _mk_eid(ElementId, i):
    """ElementId tu so nguyen: Revit 2024+ nhan Int64, Revit <= 2023 chi nhan Int32."""
    try:
        return ElementId(System.Int64(i))
    except Exception:
        return ElementId(int(i))


def _eid_int(e):
    """So nguyen cua ElementId: .Value (2024+) hoac .IntegerValue (<= 2023)."""
    try:
        return int(e.Value)
    except Exception:
        return int(e.IntegerValue)


def _revit_select_job(uiapp, editor, ids, zoom):
    """Chay trong ngu canh Revit API: chon (va phong to toi) cac thanh dam cua dam dang xem."""
    from Autodesk.Revit.DB import ElementId
    from System.Collections.Generic import List
    uidoc = uiapp.ActiveUIDocument
    d_ = uidoc.Document
    col = List[ElementId]()
    for i in ids:
        eid = _mk_eid(ElementId, i)
        if d_.GetElement(eid) is not None:
            col.Add(eid)
    uidoc.Selection.SetElementIds(col)
    if zoom and col.Count:
        try:
            uidoc.ShowElements(col)
        except Exception:
            pass
    editor.status.Text = (u"Đã chọn %d thanh dầm trong Revit." % col.Count) if col.Count else \
        u"Không tìm thấy thanh dầm nào trong model đang mở (có thể là file của dự án khác)."


def _revit_pull_job(uiapp, editor):
    uidoc = uiapp.ActiveUIDocument
    editor.on_revit_ids([_eid_int(i) for i in uidoc.Selection.GetElementIds()])


def main():
    ed = getattr(builtins, '_bm_editor', None)
    if ed is not None:                                # da mo roi: dua cua so len truoc
        try:
            if not ed.f.IsDisposed:
                if ed.f.WindowState == FormWindowState.Minimized:
                    ed.f.WindowState = FormWindowState.Normal
                ed.f.Activate()
                return
        except Exception:
            pass
        builtins._bm_editor = None
    p = pick_file()
    if not p:
        return
    try:
        m = R.Model(p)
    except Exception as ex:
        MessageBox.Show(str(ex), u"Thép dầm", MessageBoxButtons.OK, MessageBoxIcon.Error)
        return
    if not m.beams:
        MessageBox.Show(u"Sheet Nhip không có dầm nào.", u"Thép dầm")
        return
    m.add_sample()
    Editor(m).run()


try:
    main()
except Exception:
    MessageBox.Show(traceback.format_exc(), u"Thép dầm - lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error)
